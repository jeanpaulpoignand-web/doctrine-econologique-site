# QCM démocratie décisionnelle — Pilier 13

Maquette React/Vite du système **« Votez vos idées »** : QCM sur 12 axes, matching avec 10 partis, puis affichage du suivi par 3 barres.

## Objectif

Option B validée : démonstrateur public fonctionnel, sans base de données ni backend, hébergeable sur GitHub Pages.

## Fonctionnalités

- Parcours « Je ne sais pas pour qui voter »
- QCM sur 12 axes fondamentaux
- Matching automatique avec 10 partis
- Vote final libre
- Confirmation avec suivi des 3 barres :
  - vote personnel ;
  - résultat peuple à 20h ;
  - suivi d'exécution.

## Lancer localement

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Notes

- Les résultats peuple et le suivi d'exécution sont simulés dans cette V1.
- Le composant utilise React, Vite, Tailwind CSS et lucide-react.
- Le fichier source Claude original du composant est conservé dans `_sources-originales-claude/`.
