# Installation depuis iPad vers GitHub

1. Télécharger le ZIP V3.
2. Ouvrir l'app Fichiers.
3. Toucher le ZIP pour le décompresser.
4. Ouvrir GitHub dans Safari/Chrome en mode ordinateur.
5. Aller dans le dépôt cible.
6. `Add file` → `Upload files`.
7. Uploader le dossier `qcm-democratie-decisionnelle` décompressé, pas le ZIP lui-même.
8. Commit conseillé :

```text
Ajout QCM démocratie décisionnelle Pilier 13
```

Si GitHub affiche seulement le `.zip`, ne pas valider : il faut uploader le dossier décompressé.
