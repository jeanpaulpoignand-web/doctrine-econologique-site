# Manifest des sources originales Claude validées

Les noms originaux Claude sont conservés pour traçabilité. Le JSX complet est inclus intégralement dans ce dossier.

## Sources validées

- 🟢 01_P13_README_Et_si_on_changeait_le_mode_de_vote_[Claude_2026].md — validé
- 🟢 01_P13_FAQ_30_Questions_Reponses_[Claude_2026].md — validé
- 🔵 02B_P13_VoteParIdees_Component_[Claude_2026].jsx — validé, 36 082 octets
- 🔵 02B P13 Mockup Resultats 3Barres [Claude 2026].html — validé
- 🟠 04B_P13_Systeme_3_Barres_Technique_[Claude_2026].md — validé
- 🟠 04B_P13_Les_12_Axes_Positions_Partis_[Claude_2026].md — validé
- 🟠 04B_P13_Prospective_V2_V_Infini_Democratie_Directe_[Claude_2026].md — validé

## Correspondance GitHub

- `src/VoteParIdees.jsx` ← JSX original Claude complet
- `README.md` ← README public GitHub adapté
- `docs/` ← documentation projet
- `notes/` ← prospective
- `mockups/` ← mockup HTML de consultation
