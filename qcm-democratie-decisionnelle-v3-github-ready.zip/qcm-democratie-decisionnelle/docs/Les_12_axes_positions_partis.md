# Les 12 axes — positions des partis

Document source Claude validé dans Google Drive :
`🟠 04B_P13_Les_12_Axes_Positions_Partis_[Claude_2026].md`

Axes : UE, Nucléaire & Énergie, Fiscalité, Immigration, Retraite, Emploi, Santé, Justice, Défense, Agriculture, Industrie, Éducation.

Le composant React intègre les scores 0–100 des 10 partis utilisés pour le matching.
