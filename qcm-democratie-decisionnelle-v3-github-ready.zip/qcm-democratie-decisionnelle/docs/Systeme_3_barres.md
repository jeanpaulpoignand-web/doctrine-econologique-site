# Système des 3 barres

Document source Claude validé dans Google Drive :
`🟠 04B_P13_Systeme_3_Barres_Technique_[Claude_2026].md`

Résumé :

1. Votre vote personnel.
2. Résultat à 20h, agrégation du peuple.
3. Suivi d'exécution gouvernementale dans le temps.

Cette V1 utilise des données simulées ; la V2 prévoit des données gouvernementales vérifiables.
