# Prospective V2 / V∞

Document source Claude validé dans Google Drive :
`🟠 04B_P13_Prospective_V2_V_Infini_Democratie_Directe_[Claude_2026].md`

Trajectoire :

- V1 : vote parti + QCM idées + 3 barres simulées.
- V2 : vote direct par idées + suivi réel.
- V∞ : démocratie semi-directe stabilisée.
