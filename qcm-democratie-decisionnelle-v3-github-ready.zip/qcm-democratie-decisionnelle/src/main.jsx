import React from 'react';
import { createRoot } from 'react-dom/client';
import VoteParIdees from './VoteParIdees.jsx';
import './styles.css';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <VoteParIdees />
  </React.StrictMode>
);
