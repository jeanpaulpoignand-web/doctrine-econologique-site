# Installation iPad / GitHub — QCM démocratie décisionnelle V4

Version corrigée pour build GitHub Actions avec Tailwind CSS v4.

## À faire
1. Uploader `qcm-democratie-decisionnelle-v4-github-ready.zip` à la racine du dépôt.
2. Modifier le workflow pour chercher ce fichier V4.
3. Lancer `Install QCM Democratie Decisionnelle from ZIP`.
