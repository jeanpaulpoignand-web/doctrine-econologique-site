/**
 * ============================================================
 * Pilier 13 — Démocratie Décisionnelle
 * 02B — QCM 12 Axes + Matching + Suivi (3 Barres)
 * ============================================================
 * 
 * Porteur: Jean Paul Poignand (JP)
 * Réalisation: Claude (Anthropic)
 * Date: Mai 2026
 * Version: 1.0
 * Statut: Maquette prospective — travail réalisé avec Claude
 * 
 * Description:
 * Composant React complet pour système "Et si on changeait le mode de vote?"
 * - QCM Flash/Blanc sur 12 axes fondamentaux
 * - Matching automatique avec 10 partis politiques
 * - Affichage des 3 barres de suivi (personnel, résultat 20h, exécution)
 * - Vote libre (choix du parti)
 * - Confirmation avec traçabilité
 * 
 * Mode parallèle: Distinct du QCM 25 questions existant (Grok/ChatGPT/Gemini)
 * 
 * ============================================================
 */

import React, { useState } from 'react';
import { ChevronRight, RotateCcw } from 'lucide-react';

const VoteParIdees = () => {
  const [screen, setScreen] = useState('intro'); // intro, path-choice, qcm, results, final-vote
  const [path, setPath] = useState(null); // 'direct' ou 'ideas'
  const [answers, setAnswers] = useState({});
  const [finalVote, setFinalVote] = useState(null);
  const [showDetailedView, setShowDetailedView] = useState(false);

  // Données des partis avec positions sur chaque axe (0 = contre, 50 = neutre, 100 = pour)
  const parties = [
    { id: 'rn', name: 'Rassemblement National', color: '#003DA5' },
    { id: 'renaissance', name: 'Renaissance', color: '#FFA500' },
    { id: 'ps', name: 'Parti Socialiste', color: '#E4003B' },
    { id: 'lr', name: 'Les Républicains', color: '#0066CC' },
    { id: 'lfi', name: 'La France Insoumise', color: '#C41E3A' },
    { id: 'eelv', name: 'Europe Écologie', color: '#4CA454' },
    { id: 'horizons', name: 'Horizons', color: '#1E90FF' },
    { id: 'modem', name: 'MoDem', color: '#FFD700' },
    { id: 'reconquete', name: 'Reconquête', color: '#8B0000' },
    { id: 'pcf', name: 'Parti Communiste', color: '#E61E00' }
  ];

  const axes = [
    {
      id: 'ue',
      name: 'Union Européenne',
      description: 'Vision pour l\'UE',
      questions: [
        'Pensez-vous que la France doit renégocier ses rapports avec l\'UE?',
        'Faut-il approfondir l\'intégration européenne?'
      ],
      positions: {
        rn: 35,        // Euro-critique
        renaissance: 75, // Pro-UE intégration
        ps: 70,         // Pro-UE sociale
        lr: 60,         // Pro-UE libérale
        lfi: 40,        // Critique de l'UE libérale
        eelv: 75,       // Pro-UE écologiste
        horizons: 78,   // Pro-UE centriste
        modem: 80,      // Pro-UE progressive
        reconquete: 20, // Anti-UE intégrationniste
        pcf: 35         // Critique UE libérale
      }
    },
    {
      id: 'nucleaire',
      name: 'Nucléaire & Énergie',
      description: 'Politique énergétique',
      questions: [
        'La France doit-elle développer davantage l\'énergie nucléaire?',
        'Les énergies renouvelables doivent-elles remplacer le nucléaire?'
      ],
      positions: {
        rn: 85,         // 20 réacteurs
        renaissance: 80, // 14 EPR + renouvelables
        ps: 45,         // Flou volontaire
        lr: 85,         // Pro-nucléaire fort
        lfi: 30,        // Critique du nucléaire
        eelv: 15,       // 100% renouvelables, sortie nucléaire
        horizons: 75,   // Mix nucléaire+renouvelables
        modem: 70,      // Mix équilibré
        reconquete: 80, // Pro-nucléaire
        pcf: 50         // Position flue
      }
    },
    {
      id: 'fiscalite',
      name: 'Fiscalité & Impôts',
      description: 'Politique fiscale',
      questions: [
        'Faut-il augmenter les impôts sur les plus riches?',
        'Devons-nous réintroduire l\'ISF?'
      ],
      positions: {
        rn: 30,         // Baisse TVA, réduction dépense
        renaissance: 50, // Fiscalité stable
        ps: 85,         // ISF + impôts riches
        lr: 25,         // Baisse impôts
        lfi: 90,        // ISF + superprofits
        eelv: 80,       // Impôt écologique
        horizons: 45,   // Modérée
        modem: 50,      // Stable-progressive
        reconquete: 35, // Baisse impôts
        pcf: 85         // Redistribution
      }
    },
    {
      id: 'immigration',
      name: 'Immigration',
      description: 'Politique migratoire',
      questions: [
        'La politique migratoire doit-elle être plus restrictive?',
        'Faut-il faciliter l\'accès à la nationalité?'
      ],
      positions: {
        rn: 15,         // Très restrictif
        renaissance: 55, // Équilibré
        ps: 75,         // Accueillant
        lr: 40,         // Restrictif modéré
        lfi: 80,        // Accueillant
        eelv: 75,       // Accueillant
        horizons: 60,   // Équilibré-ouvert
        modem: 65,      // Ouvert modéré
        reconquete: 10, // Très restrictif
        pcf: 80         // Accueillant
      }
    },
    {
      id: 'retraite',
      name: 'Retraite',
      description: 'Politique des retraites',
      questions: [
        'Faut-il baisser l\'âge légal de retraite?',
        'Les pensions doivent-elles augmenter?'
      ],
      positions: {
        rn: 45,         // Débat interne
        renaissance: 35, // Maintien 64-65
        ps: 80,         // Retour 60 ans
        lr: 30,         // Maintien/flexibilité
        lfi: 85,        // 60 ans + augmentation
        eelv: 75,       // 60 ans
        horizons: 40,   // Modérée
        modem: 38,      // Modérée
        reconquete: 50, // Débat interne
        pcf: 90         // 60 ans plein
      }
    },
    {
      id: 'emploi',
      name: 'Emploi & Travail',
      description: 'Politique du travail',
      questions: [
        'Les 35 heures doivent-elles être maintenues?',
        'Faut-il augmenter les salaires?'
      ],
      positions: {
        rn: 40,         // Flexibiliser
        renaissance: 55, // Flexibilité
        ps: 80,         // Maintien 35h
        lr: 35,         // Flexibiliser
        lfi: 85,        // Maintien 35h
        eelv: 70,       // Réduction long terme
        horizons: 50,   // Modérée
        modem: 55,      // Flexible
        reconquete: 40, // Flexibiliser
        pcf: 85         // Augmentation salaires
      }
    },
    {
      id: 'sante',
      name: 'Santé & Dépendance',
      description: 'Politique de santé',
      questions: [
        'Faut-il augmenter le budget de santé?',
        'Comment financer l\'accompagnement des personnes âgées?'
      ],
      positions: {
        rn: 50,         // Régulation AME
        renaissance: 60, // Budget stable + efficience
        ps: 85,         // Budget accru
        lr: 55,         // Efficience + privé
        lfi: 88,        // Budget massif + public
        eelv: 82,       // Budget + prévention
        horizons: 65,   // Modéré progressif
        modem: 62,      // Équilibré
        reconquete: 55, // Limitation AME
        pcf: 87         // Service public fort
      }
    },
    {
      id: 'justice',
      name: 'Justice & Sécurité',
      description: 'Politique de sécurité',
      questions: [
        'Faut-il augmenter la sévérité des peines?',
        'Quelle approche: répression ou police de proximité?'
      ],
      positions: {
        rn: 85,         // Peines plancher, légitime défense
        renaissance: 65, // Équilibré, mineurs, police moderne
        ps: 35,         // Police proximité, droits
        lr: 75,         // Sévérité + efficience
        lfi: 30,        // Police proximité, abolition peine mort
        eelv: 32,       // Réinsertion, police communautaire
        horizons: 60,   // Équilibré
        modem: 62,      // Modéré répression
        reconquete: 82, // Sévérité forte
        pcf: 28         // Prévention, droits
      }
    },
    {
      id: 'defense',
      name: 'Défense & Souveraineté',
      description: 'Politique militaire',
      questions: [
        'Faut-il augmenter le budget militaire?',
        'La France doit-elle renforcer son indépendance vis-à-vis de l\'OTAN?'
      ],
      positions: {
        rn: 70,         // Pensions militaires, indépendance
        renaissance: 75, // Budget croissant, OTAN intégré
        ps: 65,         // Budget modéré, coopération
        lr: 78,         // Budget + équipements
        lfi: 45,        // Budget limité, paix
        eelv: 35,       // Budget réduit, diplomatie
        horizons: 72,   // Budget + modernisation
        modem: 70,      // Budget + OTAN
        reconquete: 72, // Indépendance France
        pcf: 42         // Paix, budget réduit
      }
    },
    {
      id: 'agriculture',
      name: 'Agriculture & Alimentaire',
      description: 'Politique agricole',
      questions: [
        'Faut-il privilégier l\'agriculture biologique?',
        'La souveraineté alimentaire doit-elle être une priorité?'
      ],
      positions: {
        rn: 65,         // Souveraineté alimentaire
        renaissance: 60, // Transition progressive
        ps: 75,         // Bio + circuits courts
        lr: 50,         // Productivité équilibrée
        lfi: 80,        // Bio + paysannat
        eelv: 88,       // 100% bio, agroécologie
        horizons: 58,   // Transition modérée
        modem: 55,      // Équilibre productivité-durabilité
        reconquete: 68, // Souveraineté, productivité
        pcf: 82         // Paysannat, bio
      }
    },
    {
      id: 'industrie',
      name: 'Industrie & Technologie',
      description: 'Souveraineté industrielle',
      questions: [
        'Faut-il relocaliser la production en France?',
        'Comment garantir notre indépendance technologique?'
      ],
      positions: {
        rn: 80,         // Relocalisation, souveraineté
        renaissance: 70, // Fonds souveraineté, innovation
        ps: 65,         // Relocalisation sélective
        lr: 60,         // Compétitivité + souveraineté
        lfi: 75,        // Relocalisation, planification
        eelv: 70,       // Industrie verte
        horizons: 65,   // Équilibre marché-souveraineté
        modem: 62,      // Innovation + compétitivité
        reconquete: 78, // Souveraineté forte
        pcf: 80         // Planification, relocalisation
      }
    },
    {
      id: 'education',
      name: 'Éducation',
      description: 'Politique éducative',
      questions: [
        'Faut-il augmenter le budget de l\'éducation?',
        'L\'école doit-elle être plus centralisée ou décentralisée?'
      ],
      positions: {
        rn: 65,         // Budget + autorité, centralisé
        renaissance: 68, // Budget + réforme, autonomie
        ps: 85,         // Budget massif, égalité
        lr: 55,         // Efficience, décentralisation
        lfi: 88,        // Budget massif, public fort
        eelv: 82,       // Budget + transition écologique
        horizons: 65,   // Budget modéré, réforme
        modem: 62,      // Budget + autonomie
        reconquete: 70, // Budget + autorité, transmission
        pcf: 87         // Budget massif, égalité
      }
    }
  ];

  // Calcul du matching
  const calculateMatching = () => {
    const scores = {};
    
    parties.forEach(party => {
      let totalScore = 0;
      let answeredAxes = 0;

      axes.forEach(axis => {
        if (answers[axis.id] !== undefined) {
          const userPosition = answers[axis.id];
          const partyPosition = axis.positions[party.id];
          const diff = Math.abs(userPosition - partyPosition);
          const alignement = Math.max(0, 100 - diff);
          totalScore += alignement;
          answeredAxes++;
        }
      });

      scores[party.id] = answeredAxes > 0 ? Math.round(totalScore / answeredAxes) : 0;
    });

    return scores;
  };

  const handleAnswer = (axisId, value) => {
    setAnswers(prev => ({
      ...prev,
      [axisId]: value
    }));
  };

  const handlePathChoice = (chosenPath) => {
    setPath(chosenPath);
    if (chosenPath === 'direct') {
      setScreen('final-vote');
    } else {
      setScreen('qcm');
    }
  };

  const handleQCMComplete = () => {
    setScreen('results');
  };

  const handleFinalVote = (partyId) => {
    setFinalVote(partyId);
    setScreen('confirmation');
  };

  const handleReset = () => {
    setScreen('intro');
    setPath(null);
    setAnswers({});
    setFinalVote(null);
  };

  const matching = path === 'ideas' ? calculateMatching() : {};
  const sortedParties = path === 'ideas' 
    ? [...parties].sort((a, b) => matching[b.id] - matching[a.id])
    : parties;

  // ÉCRAN: Intro
  if (screen === 'intro') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 text-white p-6">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="mb-12 pt-8">
            <div className="inline-block px-4 py-2 bg-blue-600/20 border border-blue-500 rounded-lg mb-4">
              <span className="text-sm font-semibold text-blue-300">MAQUETTE DÉMOCRATIQUE</span>
            </div>
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
              Votez par les idées
            </h1>
            <p className="text-xl text-slate-300 mb-8">
              Un système où vous votez pour ce qui compte vraiment, pas pour un parti.
            </p>
          </div>

          {/* Concept explainant */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-8 mb-8">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-3">
              <span className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-sm font-bold">?</span>
              Pourquoi ce système?
            </h2>
            <div className="space-y-4 text-slate-300">
              <p>
                🗳️ <strong>Aujourd'hui:</strong> Vous votez pour un parti, même si 30% de son programme ne vous plaît pas.
              </p>
              <p>
                💡 <strong>Avec cette maquette:</strong> Vous répondez sur ce qui vous importe vraiment — l'UE, l'énergie, les impôts, l'emploi. À la fin, le système vous montre quel parti vous correspond le plus.
              </p>
              <p>
                🎯 <strong>L'intérêt:</strong> Voir si vos idées vraiment alignées correspondent au parti que vous aviez l'intention de voter.
              </p>
            </div>
          </div>

          {/* Deux chemins */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {/* Chemin 1: Idées */}
            <button
              onClick={() => handlePathChoice('ideas')}
              className="group relative bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-8 text-left hover:shadow-2xl hover:shadow-blue-500/30 transition-all duration-300 transform hover:scale-105"
            >
              <div className="absolute top-4 right-4 text-4xl">🧭</div>
              <h3 className="text-2xl font-bold mb-3">Je ne sais pas pour qui voter</h3>
              <p className="text-blue-100 mb-6">
                Répondez à un QCM sur vos idées. Le système vous proposera le(s) parti(s) le plus aligné(s).
              </p>
              <div className="flex items-center gap-2 text-blue-200 group-hover:translate-x-2 transition-transform">
                Commencer le QCM <ChevronRight size={20} />
              </div>
            </button>

            {/* Chemin 2: Vote direct */}
            <button
              onClick={() => handlePathChoice('direct')}
              className="group relative bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-xl p-8 text-left hover:shadow-2xl hover:shadow-emerald-500/30 transition-all duration-300 transform hover:scale-105"
            >
              <div className="absolute top-4 right-4 text-4xl">✓</div>
              <h3 className="text-2xl font-bold mb-3">Je sais pour qui voter</h3>
              <p className="text-emerald-100 mb-6">
                Accédez directement au formulaire de vote et choisissez votre parti.
              </p>
              <div className="flex items-center gap-2 text-emerald-200 group-hover:translate-x-2 transition-transform">
                Voter directement <ChevronRight size={20} />
              </div>
            </button>
          </div>

          {/* Footer info */}
          <div className="border-t border-slate-700 pt-8 text-sm text-slate-400">
            <p className="mb-2">
              ⚠️ <strong>Important:</strong> Ce vote est informatif et pédagogique. À la fin du QCM, vous conservez le droit de choisir le parti de votre préférence, même s'il n'est pas le meilleur match.
            </p>
            <p>
              C'est cela, la démocratie: la liberté de choix prime sur l'algorithme.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // ÉCRAN: QCM
  if (screen === 'qcm') {
    const answeredCount = Object.keys(answers).length;
    const totalAxes = axes.length;
    const progress = (answeredCount / totalAxes) * 100;

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 text-white p-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <button
              onClick={() => setScreen('intro')}
              className="text-slate-400 hover:text-white mb-6 flex items-center gap-2 transition"
            >
              ← Retour
            </button>
            <h1 className="text-4xl font-bold mb-4">Vos idées, votre vote</h1>
            <div className="w-full bg-slate-700 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-500 to-cyan-400 h-2 rounded-full transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-slate-400 text-sm mt-2">{answeredCount} sur {totalAxes} thèmes</p>
          </div>

          {/* QCM Items */}
          <div className="space-y-8">
            {axes.map((axis, idx) => (
              <div key={axis.id} className="bg-slate-800/50 border border-slate-700 rounded-xl p-8">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <div className="text-sm font-semibold text-blue-400 mb-2">Thème {idx + 1} / {axes.length}</div>
                    <h3 className="text-2xl font-bold">{axis.name}</h3>
                    <p className="text-slate-400 mt-1">{axis.description}</p>
                  </div>
                  <span className="text-3xl">{axis.id === 'ue' && '🇪🇺' || axis.id === 'nucleaire' && '⚛️' || axis.id === 'fiscalite' && '💰' || axis.id === 'immigration' && '👥' || axis.id === 'retraite' && '📅' || axis.id === 'emploi' && '💼' || axis.id === 'sante' && '🏥' || axis.id === 'justice' && '⚖️' || axis.id === 'defense' && '🛡️' || axis.id === 'agriculture' && '🌾' || axis.id === 'industrie' && '🏭' || axis.id === 'education' && '📚' || '❓'}</span>
                </div>

                <div className="space-y-4">
                  <p className="text-slate-300 font-medium">{axis.questions[0]}</p>
                  
                  {/* Slider */}
                  <div className="space-y-2">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={answers[axis.id] || 50}
                      onChange={(e) => handleAnswer(axis.id, parseInt(e.target.value))}
                      className="w-full h-3 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>Fortement contre</span>
                      <span>Neutre</span>
                      <span>Fortement pour</span>
                    </div>
                  </div>

                  {/* Score indicator */}
                  <div className="flex items-center justify-center gap-4 mt-4 p-3 bg-slate-700/30 rounded-lg">
                    <span className="text-sm text-slate-300">Votre position:</span>
                    <span className="text-lg font-bold text-blue-400">{answers[axis.id] || 50}/100</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Action button */}
          <div className="mt-12 flex gap-4">
            <button
              onClick={() => setScreen('intro')}
              className="flex-1 py-3 px-6 rounded-lg border border-slate-600 hover:border-slate-400 transition text-slate-300 hover:text-white font-semibold"
            >
              Annuler
            </button>
            <button
              onClick={handleQCMComplete}
              disabled={answeredCount < totalAxes}
              className="flex-1 py-3 px-6 rounded-lg bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 disabled:opacity-50 disabled:cursor-not-allowed transition font-semibold"
            >
              Voir mes résultats →
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ÉCRAN: Résultats (matching)
  if (screen === 'results') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 text-white p-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">Vos résultats</h1>
          <p className="text-slate-400 mb-8">
            Voici l'alignement entre vos réponses et le programme de chaque parti.
          </p>

          {/* Résultats */}
          <div className="space-y-4 mb-12">
            {sortedParties.map((party, idx) => {
              const score = matching[party.id] || 0;
              const isTop = idx === 0;
              
              return (
                <div
                  key={party.id}
                  className={`rounded-xl p-6 transition-all ${
                    isTop 
                      ? 'bg-gradient-to-r from-blue-600/30 to-blue-500/20 border-2 border-blue-500' 
                      : 'bg-slate-800/50 border border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div 
                        className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold"
                        style={{ backgroundColor: party.color }}
                      >
                        {idx + 1}
                      </div>
                      <div>
                        <h3 className="text-lg font-bold">{party.name}</h3>
                        {isTop && <p className="text-sm text-blue-300">✨ Meilleur match</p>}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-4xl font-bold text-blue-400">{score}%</div>
                      <div className="w-32 h-2 bg-slate-700 rounded-full mt-2">
                        <div 
                          className="h-2 rounded-full transition-all"
                          style={{ 
                            width: `${score}%`,
                            backgroundColor: party.color 
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Call to action */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-8 mb-8">
            <h2 className="text-2xl font-bold mb-4">Prêt à voter?</h2>
            <p className="text-slate-300 mb-6">
              Vous pouvez maintenant choisir le parti pour lequel vous souhaitez voter. Vous êtes libre de sélectionner le meilleur match proposé, ou un autre parti si vous le préférez.
            </p>
            <button
              onClick={() => setScreen('final-vote')}
              className="w-full py-3 px-6 rounded-lg bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 transition font-semibold text-lg"
            >
              Passer au vote →
            </button>
          </div>

          {/* Back button */}
          <button
            onClick={() => setScreen('qcm')}
            className="text-slate-400 hover:text-white transition"
          >
            ← Retour au QCM
          </button>
        </div>
      </div>
    );
  }

  // ÉCRAN: Vote final
  if (screen === 'final-vote') {
    const matching = path === 'ideas' ? calculateMatching() : {};
    const topMatch = path === 'ideas' ? Object.entries(matching).sort((a, b) => b[1] - a[1])[0] : null;

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 text-white p-6">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => setScreen(path === 'ideas' ? 'results' : 'intro')}
            className="text-slate-400 hover:text-white mb-8 flex items-center gap-2 transition"
          >
            ← Retour
          </button>

          <h1 className="text-4xl font-bold mb-2">Choisissez votre parti</h1>
          {path === 'ideas' && topMatch && (
            <p className="text-slate-400 mb-8">
              💡 Conseil: <strong>{parties.find(p => p.id === topMatch[0]).name}</strong> est le meilleur match ({topMatch[1]}%), mais vous êtes libre de choisir.
            </p>
          )}
          {path === 'direct' && (
            <p className="text-slate-400 mb-8">
              Sélectionnez le parti pour lequel vous souhaitez voter.
            </p>
          )}

          {/* Grid de partis */}
          <div className="grid md:grid-cols-2 gap-4 mb-12">
            {parties.map(party => (
              <button
                key={party.id}
                onClick={() => handleFinalVote(party.id)}
                className="relative group rounded-xl p-6 border-2 border-slate-700 hover:border-slate-500 transition bg-slate-800/30 hover:bg-slate-800/60 text-left"
              >
                <div 
                  className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-10 transition"
                  style={{ backgroundColor: party.color }}
                />
                <div className="relative">
                  <div 
                    className="w-12 h-12 rounded-lg mb-4"
                    style={{ backgroundColor: party.color }}
                  />
                  <h3 className="font-bold text-lg mb-2">{party.name}</h3>
                  {path === 'ideas' && matching[party.id] && (
                    <p className="text-sm text-blue-300">
                      Alignement: <strong>{matching[party.id]}%</strong>
                    </p>
                  )}
                </div>
              </button>
            ))}
          </div>

          {/* Footer message */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 text-center">
            <p className="text-slate-300">
              ✓ Votre vote sera enregistré et comptabilisé. <br/>
              <span className="text-sm text-slate-400">Données anonymes envoyées au ministère de l'Intérieur.</span>
            </p>
          </div>
        </div>
      </div>
    );
  }

  // ÉCRAN: Confirmation du vote + suivi 3 barres
  if (screen === 'confirmation') {
    const selectedParty = parties.find(p => p.id === finalVote);
    const matching = path === 'ideas' ? calculateMatching() : {};
    const score = matching[finalVote];

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 text-white p-6">
        <div className="max-w-4xl mx-auto">
          {/* Confirmation box */}
          <div className="bg-slate-800/50 border border-emerald-500/50 rounded-xl p-12 mb-8 text-center">
            <div 
              className="w-24 h-24 rounded-2xl mx-auto mb-6 flex items-center justify-center text-6xl"
              style={{ backgroundColor: selectedParty.color }}
            />
            <h1 className="text-4xl font-bold mb-4">Vote enregistré!</h1>
            <p className="text-2xl text-emerald-300 font-semibold mb-6">
              {selectedParty.name}
            </p>
            
            {path === 'ideas' && score !== undefined && (
              <div className="bg-slate-700/30 rounded-lg p-4 mb-6">
                <p className="text-slate-300 mb-2">Votre alignement avec ce parti</p>
                <p className="text-3xl font-bold text-emerald-400">{score}%</p>
              </div>
            )}

            <p className="text-slate-400 mb-8">
              Merci d'avoir participé à ce scrutin pédagogique. <br/>
              Votre vote a été transmis en toute sécurité.
            </p>
          </div>

          {/* SYSTÈME DE SUIVI À 3 BARRES */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-8 mb-8">
            <h2 className="text-2xl font-bold mb-2">📊 Suivi de vos idées</h2>
            <p className="text-slate-400 mb-8">
              Voici comment vos 12 idées évoluent — de votre vote personnel, aux résultats nationaux à 20h, jusqu'à l'exécution.
            </p>

            <div className="space-y-8">
              {axes.map((axis) => {
                const personalScore = answers[axis.id] || 50;
                const populationResult = Math.round((personalScore + Math.random() * 30 - 15)); // Simulation
                const executionProgress = Math.floor(Math.random() * 35); // 0-35% au départ
                
                return (
                  <div key={axis.id} className="border-b border-slate-700/50 pb-6 last:border-b-0">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="font-bold text-slate-100">{axis.name}</h3>
                        <p className="text-xs text-slate-500">{axis.description}</p>
                      </div>
                      <span className="text-2xl">{
                        axis.id === 'ue' && '🇪🇺' || 
                        axis.id === 'nucleaire' && '⚛️' || 
                        axis.id === 'fiscalite' && '💰' || 
                        axis.id === 'immigration' && '👥' || 
                        axis.id === 'retraite' && '📅' || 
                        axis.id === 'emploi' && '💼' ||
                        axis.id === 'sante' && '🏥' ||
                        axis.id === 'justice' && '⚖️' ||
                        axis.id === 'defense' && '🛡️' ||
                        axis.id === 'agriculture' && '🌾' ||
                        axis.id === 'industrie' && '🏭' ||
                        axis.id === 'education' && '📚' || '❓'
                      }</span>
                    </div>

                    {/* BARRE 1: Votre vote */}
                    <div className="mb-3">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs font-semibold text-slate-300">Votre vote</span>
                        <span className="text-xs text-slate-400">{personalScore}/100</span>
                      </div>
                      <div className="w-full h-4 bg-slate-700 rounded-full overflow-hidden">
                        <div 
                          className="h-full rounded-full transition-all"
                          style={{ 
                            width: `${personalScore}%`,
                            backgroundColor: '#0ea5e9'
                          }}
                        />
                      </div>
                    </div>

                    {/* BARRE 2: Résultat à 20h (FINE) */}
                    <div className="mb-3">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs font-semibold text-slate-300">Résultat à 20h (peuple)</span>
                        <span className="text-xs text-slate-400">{populationResult}/100</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div 
                          className="h-full rounded-full transition-all"
                          style={{ 
                            width: `${Math.max(10, populationResult)}%`,
                            backgroundColor: '#64748b'
                          }}
                        />
                      </div>
                    </div>

                    {/* BARRE 3: Suivi d'exécution (FINE) */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs font-semibold text-slate-300">Suivi d'exécution</span>
                        <span className="text-xs text-slate-400">{executionProgress}% (vote du 29/05/2026)</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div 
                          className="h-full rounded-full transition-all"
                          style={{ 
                            width: `${executionProgress}%`,
                            backgroundColor: '#10b981'
                          }}
                        />
                      </div>
                      <div className="text-xs text-slate-500 mt-1 pl-1">
                        Sera mise à jour: 6 mois → 1 an → 3 ans
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Note prospective */}
          <div className="bg-slate-800/30 border border-slate-700/50 rounded-xl p-6 mb-8">
            <h3 className="font-bold text-slate-200 mb-3">📋 Note — Version 1 (actuelle)</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Cette maquette respecte l'organisation électorale actuelle : vous votez un parti, qui devient responsable de l'exécution.
              <br/><br/>
              <strong>Version 2 (future):</strong> Vous voterez directement vos 12 idées (sans intermédiaire parti). L'État exécutera selon le consensus populaire. 
              Cette première version est une <strong>rampe de transition</strong> vers la démocratie semi-directe.
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-4">
            <button
              onClick={handleReset}
              className="flex-1 py-3 px-6 rounded-lg border border-slate-600 hover:border-slate-400 transition text-slate-300 hover:text-white font-semibold flex items-center justify-center gap-2"
            >
              <RotateCcw size={18} /> Recommencer
            </button>
            <button
              onClick={() => alert('Merci d\'avoir participé à cette maquette prospective!')}
              className="flex-1 py-3 px-6 rounded-lg bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 transition font-semibold"
            >
              Quitter
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export default VoteParIdees;
