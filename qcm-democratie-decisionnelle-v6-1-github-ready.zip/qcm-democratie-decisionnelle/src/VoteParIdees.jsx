import React, { useMemo, useState } from 'react';
import './styles.css';
import { axes, parties } from './data.js';

const axisIcons = {
  ue: '🇪🇺', nucleaire: '⚛️', fiscalite: '💶', immigration: '👥', retraite: '📅', emploi: '💼',
  sante: '🏥', justice: '⚖️', defense: '🛡️', agriculture: '🌾', industrie: '🏭', education: '📚'
};

const labels = {
  ue: ['Souveraineté nationale', 'Intégration européenne'],
  nucleaire: ['Sortie / renouvelables', 'Nucléaire fort'],
  fiscalite: ['Baisse fiscale', 'Redistribution forte'],
  immigration: ['Très restrictive', 'Très ouverte'],
  retraite: ['Âge plus élevé', 'Retour plus tôt'],
  emploi: ['Flexibilité', 'Protection salaires'],
  sante: ['Efficience budget', 'Service public renforcé'],
  justice: ['Prévention', 'Sévérité'],
  defense: ['Diplomatie', 'Souveraineté militaire'],
  agriculture: ['Productivité', 'Agroécologie'],
  industrie: ['Marché ouvert', 'Relocalisation'],
  education: ['Réformes ciblées', 'Budget massif']
};

function defaultAnswers() { return Object.fromEntries(axes.map(axis => [axis.id, 50])); }
function deterministicOffset(axisId) { return axisId.split('').reduce((a, c) => a + c.charCodeAt(0), 0) % 23 - 11; }
function clamp(n) { return Math.max(0, Math.min(100, Math.round(n))); }

function App() {
  const [screen, setScreen] = useState('intro');
  const [path, setPath] = useState(null);
  const [answers, setAnswers] = useState(defaultAnswers());
  const [finalVote, setFinalVote] = useState(null);
  const answeredCount = Object.keys(answers).filter(k => answers[k] !== undefined).length;

  const matching = useMemo(() => {
    const scores = {};
    parties.forEach(party => {
      let total = 0;
      axes.forEach(axis => {
        const userPosition = answers[axis.id] ?? 50;
        const partyPosition = axis.positions[party.id];
        total += Math.max(0, 100 - Math.abs(userPosition - partyPosition));
      });
      scores[party.id] = Math.round(total / axes.length);
    });
    return scores;
  }, [answers]);

  const sortedParties = useMemo(() => [...parties].sort((a,b) => matching[b.id] - matching[a.id]), [matching]);
  const topParty = sortedParties[0];
  const selectedParty = parties.find(p => p.id === finalVote);

  function setAnswer(axisId, value) { setAnswers(prev => ({ ...prev, [axisId]: Number(value) })); }
  function reset() { setScreen('intro'); setPath(null); setAnswers(defaultAnswers()); setFinalVote(null); }

  function Bar({ value, color='var(--blue)', thin=false }) {
    return <div className={thin ? 'bar thin' : 'bar'}><span style={{ width: `${clamp(value)}%`, background: color }} /></div>;
  }
  function TopNav() {
    return <div className="top-nav"><a href="../" className="back-link">← Retour au site Doctrine</a><span className="pill">Pilier 13 · Démocratie décisionnelle</span></div>;
  }

  if (screen === 'intro') return <main className="page hero-page"><TopNav />
    <section className="hero-card">
      <div className="hero-kicker">Maquette citoyenne interactive</div>
      <h1>Et si on changeait le mode de vote ?</h1>
      <p className="hero-lead">Au lieu de voter d’abord pour une étiquette politique, vous exprimez vos positions sur 12 grands axes. Le système calcule ensuite les proximités avec les partis et affiche un suivi en trois barres : votre vote, le résultat collectif, puis l’exécution.</p>
      <div className="hero-grid">
        <button className="choice-card primary" onClick={() => { setPath('ideas'); setScreen('qcm'); }}>
          <span className="choice-icon">🧭</span><strong>Je vote par mes idées</strong><em>QCM 12 axes puis matching politique.</em>
        </button>
        <button className="choice-card secondary" onClick={() => { setPath('direct'); setScreen('final-vote'); }}>
          <span className="choice-icon">✓</span><strong>Je sais déjà pour qui voter</strong><em>Accès direct au choix final, avec suivi pédagogique.</em>
        </button>
      </div>
      <div className="promise-row"><span>12 axes</span><span>10 partis</span><span>Matching transparent</span><span>3 barres de suivi</span></div>
    </section>
  </main>;

  if (screen === 'qcm') return <main className="page"><TopNav />
    <section className="panel heading-panel">
      <button className="ghost" onClick={() => setScreen('intro')}>← Accueil</button>
      <div><p className="section-kicker">QCM 12 axes</p><h1>Vos idées, pas seulement une étiquette.</h1><p>Déplacez chaque curseur. 0 et 100 représentent les deux pôles de l’axe, pas une note morale.</p></div>
      <div className="progress-wrap"><strong>{answeredCount} / {axes.length}</strong><Bar value={answeredCount / axes.length * 100} /></div>
    </section>
    <section className="axis-grid">
      {axes.map((axis, index) => <article className="axis-card" key={axis.id}>
        <div className="axis-head"><span className="axis-emoji">{axisIcons[axis.id]}</span><div><small>Thème {index + 1} / {axes.length}</small><h2>{axis.name}</h2><p>{axis.description}</p></div></div>
        <p className="question">{axis.questions[0]}</p>
        <input className="slider" type="range" min="0" max="100" value={answers[axis.id] ?? 50} onChange={e => setAnswer(axis.id, e.target.value)} />
        <div className="scale"><span>{labels[axis.id]?.[0] || 'Contre'}</span><b>{answers[axis.id] ?? 50}/100</b><span>{labels[axis.id]?.[1] || 'Pour'}</span></div>
      </article>)}
    </section>
    <div className="actions"><button className="btn muted" onClick={reset}>Réinitialiser</button><button className="btn primary" onClick={() => setScreen('results')}>Voir mes correspondances →</button></div>
  </main>;

  if (screen === 'results') return <main className="page"><TopNav />
    <section className="panel result-hero">
      <div><p className="section-kicker">Résultat pédagogique</p><h1>Vos idées définies</h1><p>Les partis sont ici des vecteurs de transmission. Ce qui compte d’abord, ce sont les axes que vous avez exprimés.</p></div>
      <div className="winner" style={{ '--party': topParty.color }}><span>Meilleur match</span><strong>{topParty.name}</strong><b>{matching[topParty.id]}%</b></div>
    </section>
    <section className="ideas-strip">
      {axes.map(axis => <article className="mini-idea" key={axis.id}><span>{axisIcons[axis.id]}</span><strong>{axis.name}</strong><b>{answers[axis.id]}/100</b><Bar value={answers[axis.id]} thin /></article>)}
    </section>
    <section className="party-list panel"><h2>Correspondance avec les partis</h2><p className="soft">Matching par distance moyenne sur les 12 axes.</p>{sortedParties.map((party, idx) => <div className="party-row" key={party.id}><span className="rank">{idx+1}</span><strong>{party.name}</strong><Bar value={matching[party.id]} color={party.color} /><b>{matching[party.id]}%</b></div>)}</section>
    <div className="actions"><button className="btn muted" onClick={() => setScreen('qcm')}>← Modifier mes réponses</button><button className="btn primary" onClick={() => setScreen('final-vote')}>Passer au vote libre →</button></div>
  </main>;

  if (screen === 'final-vote') return <main className="page"><TopNav />
    <section className="panel heading-panel"><button className="ghost" onClick={() => setScreen(path === 'ideas' ? 'results' : 'intro')}>← Retour</button><div><p className="section-kicker">Vote libre</p><h1>Choisissez votre vecteur politique</h1><p>Le matching informe, mais ne remplace pas votre liberté démocratique.</p></div></section>
    <section className="vote-grid">{sortedParties.map(party => <button className="vote-card" key={party.id} onClick={() => { setFinalVote(party.id); setScreen('confirmation'); }} style={{ '--party': party.color }}><span className="party-dot" /><strong>{party.name}</strong><em>Alignement : {matching[party.id]}%</em></button>)}</section>
  </main>;

  if (screen === 'confirmation') return <main className="page"><TopNav />
    <section className="panel confirm"><p className="section-kicker">Vote enregistré — simulation</p><h1>{selectedParty?.name}</h1><p>Voici le tableau de bord des 12 idées : vote personnel, résultat collectif simulé, puis suivi d’exécution.</p></section>
    <section className="tracking-panel">
      {axes.map(axis => {
        const personal = answers[axis.id] ?? 50;
        const collective = clamp(personal + deterministicOffset(axis.id));
        const execution = clamp(Math.abs(deterministicOffset(axis.id)) * 4 + 8);
        return <article className="track-card" key={axis.id}>
          <div className="track-title"><span>{axisIcons[axis.id]}</span><div><strong>{axis.name}</strong><small>{axis.description}</small></div></div>
          <div className="track-line"><span>Votre vote</span><b>{personal}/100</b><Bar value={personal} color="#38bdf8" /></div>
          <div className="track-line"><span>Résultat à 20h</span><b>{collective}/100</b><Bar value={collective} color="#94a3b8" thin /></div>
          <div className="track-line"><span>Suivi d’exécution</span><b>{execution}%</b><Bar value={execution} color="#22c55e" thin /></div>
        </article>;
      })}
    </section>
    <div className="actions"><button className="btn muted" onClick={reset}>Recommencer</button><a className="btn primary" href="../">Retour au site Doctrine</a></div>
  </main>;
}

export default App;
