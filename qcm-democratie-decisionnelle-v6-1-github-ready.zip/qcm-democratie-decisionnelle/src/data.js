export const parties = [
    { id: 'rn', name: 'Rassemblement National', color: '#003DA5' },
    { id: 'renaissance', name: 'Renaissance', color: '#FFA500' },
    { id: 'ps', name: 'Parti Socialiste', color: '#E4003B' },
    { id: 'lr', name: 'Les Républicains', color: '#0066CC' },
    { id: 'lfi', name: 'La France Insoumise', color: '#C41E3A' },
    { id: 'eelv', name: 'Europe Écologie', color: '#4CA454' },
    { id: 'horizons', name: 'Horizons', color: '#1E90FF' },
    { id: 'modem', name: 'MoDem', color: '#FFD700' },
    { id: 'reconquete', name: 'Reconquête', color: '#8B0000' },
    { id: 'pcf', name: 'Parti Communiste', color: '#E61E00' }
  ];

export const axes = [
    {
      id: 'ue',
      name: 'Union Européenne',
      description: 'Vision pour l\'UE',
      questions: [
        'Pensez-vous que la France doit renégocier ses rapports avec l\'UE?',
        'Faut-il approfondir l\'intégration européenne?'
      ],
      positions: {
        rn: 35,        // Euro-critique
        renaissance: 75, // Pro-UE intégration
        ps: 70,         // Pro-UE sociale
        lr: 60,         // Pro-UE libérale
        lfi: 40,        // Critique de l'UE libérale
        eelv: 75,       // Pro-UE écologiste
        horizons: 78,   // Pro-UE centriste
        modem: 80,      // Pro-UE progressive
        reconquete: 20, // Anti-UE intégrationniste
        pcf: 35         // Critique UE libérale
      }
    },
    {
      id: 'nucleaire',
      name: 'Nucléaire & Énergie',
      description: 'Politique énergétique',
      questions: [
        'La France doit-elle développer davantage l\'énergie nucléaire?',
        'Les énergies renouvelables doivent-elles remplacer le nucléaire?'
      ],
      positions: {
        rn: 85,         // 20 réacteurs
        renaissance: 80, // 14 EPR + renouvelables
        ps: 45,         // Flou volontaire
        lr: 85,         // Pro-nucléaire fort
        lfi: 30,        // Critique du nucléaire
        eelv: 15,       // 100% renouvelables, sortie nucléaire
        horizons: 75,   // Mix nucléaire+renouvelables
        modem: 70,      // Mix équilibré
        reconquete: 80, // Pro-nucléaire
        pcf: 50         // Position flue
      }
    },
    {
      id: 'fiscalite',
      name: 'Fiscalité & Impôts',
      description: 'Politique fiscale',
      questions: [
        'Faut-il augmenter les impôts sur les plus riches?',
        'Devons-nous réintroduire l\'ISF?'
      ],
      positions: {
        rn: 30,         // Baisse TVA, réduction dépense
        renaissance: 50, // Fiscalité stable
        ps: 85,         // ISF + impôts riches
        lr: 25,         // Baisse impôts
        lfi: 90,        // ISF + superprofits
        eelv: 80,       // Impôt écologique
        horizons: 45,   // Modérée
        modem: 50,      // Stable-progressive
        reconquete: 35, // Baisse impôts
        pcf: 85         // Redistribution
      }
    },
    {
      id: 'immigration',
      name: 'Immigration',
      description: 'Politique migratoire',
      questions: [
        'La politique migratoire doit-elle être plus restrictive?',
        'Faut-il faciliter l\'accès à la nationalité?'
      ],
      positions: {
        rn: 15,         // Très restrictif
        renaissance: 55, // Équilibré
        ps: 75,         // Accueillant
        lr: 40,         // Restrictif modéré
        lfi: 80,        // Accueillant
        eelv: 75,       // Accueillant
        horizons: 60,   // Équilibré-ouvert
        modem: 65,      // Ouvert modéré
        reconquete: 10, // Très restrictif
        pcf: 80         // Accueillant
      }
    },
    {
      id: 'retraite',
      name: 'Retraite',
      description: 'Politique des retraites',
      questions: [
        'Faut-il baisser l\'âge légal de retraite?',
        'Les pensions doivent-elles augmenter?'
      ],
      positions: {
        rn: 45,         // Débat interne
        renaissance: 35, // Maintien 64-65
        ps: 80,         // Retour 60 ans
        lr: 30,         // Maintien/flexibilité
        lfi: 85,        // 60 ans + augmentation
        eelv: 75,       // 60 ans
        horizons: 40,   // Modérée
        modem: 38,      // Modérée
        reconquete: 50, // Débat interne
        pcf: 90         // 60 ans plein
      }
    },
    {
      id: 'emploi',
      name: 'Emploi & Travail',
      description: 'Politique du travail',
      questions: [
        'Les 35 heures doivent-elles être maintenues?',
        'Faut-il augmenter les salaires?'
      ],
      positions: {
        rn: 40,         // Flexibiliser
        renaissance: 55, // Flexibilité
        ps: 80,         // Maintien 35h
        lr: 35,         // Flexibiliser
        lfi: 85,        // Maintien 35h
        eelv: 70,       // Réduction long terme
        horizons: 50,   // Modérée
        modem: 55,      // Flexible
        reconquete: 40, // Flexibiliser
        pcf: 85         // Augmentation salaires
      }
    },
    {
      id: 'sante',
      name: 'Santé & Dépendance',
      description: 'Politique de santé',
      questions: [
        'Faut-il augmenter le budget de santé?',
        'Comment financer l\'accompagnement des personnes âgées?'
      ],
      positions: {
        rn: 50,         // Régulation AME
        renaissance: 60, // Budget stable + efficience
        ps: 85,         // Budget accru
        lr: 55,         // Efficience + privé
        lfi: 88,        // Budget massif + public
        eelv: 82,       // Budget + prévention
        horizons: 65,   // Modéré progressif
        modem: 62,      // Équilibré
        reconquete: 55, // Limitation AME
        pcf: 87         // Service public fort
      }
    },
    {
      id: 'justice',
      name: 'Justice & Sécurité',
      description: 'Politique de sécurité',
      questions: [
        'Faut-il augmenter la sévérité des peines?',
        'Quelle approche: répression ou police de proximité?'
      ],
      positions: {
        rn: 85,         // Peines plancher, légitime défense
        renaissance: 65, // Équilibré, mineurs, police moderne
        ps: 35,         // Police proximité, droits
        lr: 75,         // Sévérité + efficience
        lfi: 30,        // Police proximité, abolition peine mort
        eelv: 32,       // Réinsertion, police communautaire
        horizons: 60,   // Équilibré
        modem: 62,      // Modéré répression
        reconquete: 82, // Sévérité forte
        pcf: 28         // Prévention, droits
      }
    },
    {
      id: 'defense',
      name: 'Défense & Souveraineté',
      description: 'Politique militaire',
      questions: [
        'Faut-il augmenter le budget militaire?',
        'La France doit-elle renforcer son indépendance vis-à-vis de l\'OTAN?'
      ],
      positions: {
        rn: 70,         // Pensions militaires, indépendance
        renaissance: 75, // Budget croissant, OTAN intégré
        ps: 65,         // Budget modéré, coopération
        lr: 78,         // Budget + équipements
        lfi: 45,        // Budget limité, paix
        eelv: 35,       // Budget réduit, diplomatie
        horizons: 72,   // Budget + modernisation
        modem: 70,      // Budget + OTAN
        reconquete: 72, // Indépendance France
        pcf: 42         // Paix, budget réduit
      }
    },
    {
      id: 'agriculture',
      name: 'Agriculture & Alimentaire',
      description: 'Politique agricole',
      questions: [
        'Faut-il privilégier l\'agriculture biologique?',
        'La souveraineté alimentaire doit-elle être une priorité?'
      ],
      positions: {
        rn: 65,         // Souveraineté alimentaire
        renaissance: 60, // Transition progressive
        ps: 75,         // Bio + circuits courts
        lr: 50,         // Productivité équilibrée
        lfi: 80,        // Bio + paysannat
        eelv: 88,       // 100% bio, agroécologie
        horizons: 58,   // Transition modérée
        modem: 55,      // Équilibre productivité-durabilité
        reconquete: 68, // Souveraineté, productivité
        pcf: 82         // Paysannat, bio
      }
    },
    {
      id: 'industrie',
      name: 'Industrie & Technologie',
      description: 'Souveraineté industrielle',
      questions: [
        'Faut-il relocaliser la production en France?',
        'Comment garantir notre indépendance technologique?'
      ],
      positions: {
        rn: 80,         // Relocalisation, souveraineté
        renaissance: 70, // Fonds souveraineté, innovation
        ps: 65,         // Relocalisation sélective
        lr: 60,         // Compétitivité + souveraineté
        lfi: 75,        // Relocalisation, planification
        eelv: 70,       // Industrie verte
        horizons: 65,   // Équilibre marché-souveraineté
        modem: 62,      // Innovation + compétitivité
        reconquete: 78, // Souveraineté forte
        pcf: 80         // Planification, relocalisation
      }
    },
    {
      id: 'education',
      name: 'Éducation',
      description: 'Politique éducative',
      questions: [
        'Faut-il augmenter le budget de l\'éducation?',
        'L\'école doit-elle être plus centralisée ou décentralisée?'
      ],
      positions: {
        rn: 65,         // Budget + autorité, centralisé
        renaissance: 68, // Budget + réforme, autonomie
        ps: 85,         // Budget massif, égalité
        lr: 55,         // Efficience, décentralisation
        lfi: 88,        // Budget massif, public fort
        eelv: 82,       // Budget + transition écologique
        horizons: 65,   // Budget modéré, réforme
        modem: 62,      // Budget + autonomie
        reconquete: 70, // Budget + autorité, transmission
        pcf: 87         // Budget massif, égalité
      }
    }
  ];
