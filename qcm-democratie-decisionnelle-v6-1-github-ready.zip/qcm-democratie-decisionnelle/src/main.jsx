import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './VoteParIdees.jsx';

createRoot(document.getElementById('root')).render(<App />);
