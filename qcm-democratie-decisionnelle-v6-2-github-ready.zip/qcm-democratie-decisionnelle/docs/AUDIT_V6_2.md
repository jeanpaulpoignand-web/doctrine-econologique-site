# Audit V6.2 — QCM démocratie décisionnelle

Verdict : OK GitHub-ready.

## Contrôles réalisés
- Build local Vite : OK.
- Chemins GitHub Pages : `base: './'` conservé.
- CSS autonome : OK, aucun Tailwind/PostCSS.
- Package propre : React + Vite uniquement.
- 12 axes présents via `src/data.js`.
- 10 partis présents via `src/data.js`.
- Matching global présent.
- Proximité par axe ajoutée.
- Écran “Pourquoi ce système ?” ajouté.
- Séquence V1 / V2 / V3 ajoutée.
- 3 barres explicites : vote personnel, résultat à 20h, exécution réelle.
- Bouton retour site Doctrine présent.

## Réserve
La V6.2 reste une maquette prospective. Les résultats collectifs et l’exécution réelle sont simulés.
