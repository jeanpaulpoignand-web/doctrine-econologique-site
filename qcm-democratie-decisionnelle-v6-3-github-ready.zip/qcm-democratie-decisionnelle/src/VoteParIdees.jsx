import React, { useMemo, useState } from 'react';
import { axes, parties } from './data.js';

const START_ANSWERS = Object.fromEntries(axes.map(axis => [axis.id, 50]));
const medianThreshold = 50;

function clamp(value) {
  return Math.max(0, Math.min(100, Math.round(value)));
}

function simulatedCollective(axisId, personal) {
  const seed = axisId.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
  const offset = (seed % 19) - 9;
  return clamp(personal + offset);
}

function simulatedExecution(axisId, collective) {
  const seed = axisId.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
  if (collective <= medianThreshold) return 0;
  return clamp(18 + (seed % 43));
}

function importance(answer) {
  return 1 + Math.abs(answer - 50) / 50;
}

function partyAxisPosition(axis, partyId) {
  return axis.positions?.[partyId] ?? null;
}

function partyAxisConfidence(axis, partyId) {
  return axis.confidence?.[partyId] ?? 0.45;
}

function axisScore(answer, axis, partyId) {
  const position = partyAxisPosition(axis, partyId);
  if (position === null || position === undefined) return { score: 35, confidence: 0, distance: 100, documented: false };
  const distance = Math.abs(answer - position);
  const rawScore = Math.max(0, 100 - distance);
  const confidence = partyAxisConfidence(axis, partyId);
  const adjusted = rawScore * (0.65 + confidence * 0.35);
  return { score: adjusted, confidence, distance, documented: confidence >= 0.38 };
}

function computeMatching(answers) {
  return parties.map(party => {
    let total = 0;
    let weightSum = 0;
    const byAxis = axes.map(axis => {
      const answer = answers[axis.id] ?? 50;
      const weight = importance(answer);
      const detail = axisScore(answer, axis, party.id);
      total += detail.score * weight;
      weightSum += weight;
      return { axisId: axis.id, axisName: axis.name, answer, ...detail };
    });
    return {
      ...party,
      match: Math.round(total / weightSum),
      byAxis
    };
  }).sort((a, b) => b.match - a.match);
}

function computeDemocraticGaps(answers) {
  return axes.map(axis => {
    const answer = answers[axis.id] ?? 50;
    const adopted = answer > medianThreshold;
    const collective = simulatedCollective(axis.id, answer);
    const collectiveAdopted = collective > medianThreshold;
    const ranked = parties.map(party => {
      const detail = axisScore(answer, axis, party.id);
      return { ...party, ...detail };
    }).sort((a, b) => b.score - a.score);
    const best = ranked[0];
    const weakCoverage = axis.democraticVoidHint && adopted && (best.score < 68 || best.confidence < 0.42);
    const partialCoverage = adopted && !weakCoverage && (best.score < 76 || best.confidence < 0.55);
    return { axis, answer, adopted, collective, collectiveAdopted, best, weakCoverage, partialCoverage };
  });
}

function ProgressBar({ value, color = 'var(--blue)', label, kind = '' }) {
  return (
    <div className={`progress ${kind}`} aria-label={label}>
      <span style={{ width: `${clamp(value)}%`, background: color }} />
    </div>
  );
}

function TopNav({ onReset }) {
  return (
    <nav className="top-nav">
      <a href="../" className="back-link">← Retour au site Doctrine</a>
      <span className="nav-pill">Pilier 13 · Démocratie décisionnelle</span>
      <button className="ghost" onClick={onReset}>Réinitialiser</button>
    </nav>
  );
}

function MethodBox() {
  return (
    <section className="method-box" id="methode">
      <div>
        <span className="section-kicker">Méthode de calcul</span>
        <h2>Comment le résultat est calculé ?</h2>
      </div>
      <div className="method-grid">
        <article><strong>1 · Votre vote</strong><p>Chaque curseur va de 0 à 100. Au-dessus de 50, l’idée est considérée comme adoptée par vous. Plus vous êtes loin de 50, plus votre préférence pèse.</p></article>
        <article><strong>2 · Résultat à 20h</strong><p>Dans cette maquette, il est simulé. Dans une version réelle, il serait issu de l’agrégation des votes citoyens par question.</p></article>
        <article><strong>3 · Matching</strong><p>Le système compare vos réponses aux positions documentées des partis. Les positions peu documentées sont pénalisées.</p></article>
        <article><strong>4 · Angle mort démocratique</strong><p>Si aucun parti ne couvre clairement une attente adoptée, le QCM le signale comme un vide de représentation.</p></article>
      </div>
    </section>
  );
}

function Intro({ start }) {
  return (
    <main className="page hero-page">
      <section className="hero-card">
        <span className="hero-kicker">Maquette prospective · Pilier 13</span>
        <h1>Et si on votait différemment ?</h1>
        <p className="hero-lead">Continuer à voter pour des partis politiques, oui… <strong>mais</strong> avec un outil pour tester ses idées avant, comprendre les écarts et suivre l’application réelle des engagements.</p>
        <div className="concept-banner">
          <strong>Ce n’est pas un comparateur partisan classique.</strong>
          <span>Vous votez d’abord vos idées. Les partis ne s’affichent qu’à la fin pour éviter d’influencer vos réponses.</span>
        </div>
        <div className="hero-grid">
          <button className="choice-card" onClick={() => start('ideas')}>
            <span className="choice-icon">🗳️</span>
            <strong>Je vote par mes idées</strong>
            <em>12 questions concrètes, des curseurs, puis un diagnostic final.</em>
          </button>
          <button className="choice-card secondary" onClick={() => start('known')}>
            <span className="choice-icon">🧭</span>
            <strong>Je sais déjà pour qui voter</strong>
            <em>Comparez ensuite votre intuition avec le résultat calculé.</em>
          </button>
        </div>
        <div className="promise-row">
          <span>12 axes</span><span>15 partis</span><span>3 barres de suivi</span><span>Angles morts démocratiques</span>
        </div>
        <MethodBox />
      </section>
    </main>
  );
}

function AxisCard({ axis, value, onChange }) {
  const collective = simulatedCollective(axis.id, value);
  const execution = simulatedExecution(axis.id, collective);
  return (
    <article className="axis-card">
      <div className="axis-head">
        <span className="axis-emoji">{axis.icon}</span>
        <div>
          <small>{axis.name}</small>
          <h2>{axis.question}</h2>
          <p>{axis.explanation}</p>
        </div>
      </div>
      <div className="scale"><span>{axis.left}</span><b>{value}/100</b><span>{axis.right}</span></div>
      <input className="slider" type="range" min="0" max="100" value={value} onChange={event => onChange(axis.id, Number(event.target.value))} />
      <div className="three-bars">
        <div className="bar-line"><span>1 · Votre vote</span><b>{value}/100</b><ProgressBar value={value} color="#ffffff" kind="personal" /></div>
        <div className="bar-line"><span>2 · Résultat à 20h</span><b>{collective}/100</b><ProgressBar value={collective} color="#38bdf8" /></div>
        <div className="bar-line"><span>3 · Application réelle</span><b>{execution}%</b><ProgressBar value={execution} color="#22c55e" /></div>
      </div>
    </article>
  );
}

function Questionnaire({ answers, setAnswer, showResults, reset }) {
  const adopted = axes.filter(axis => (answers[axis.id] ?? 50) > 50).length;
  return (
    <main className="page">
      <TopNav onReset={reset} />
      <section className="panel heading-panel">
        <div>
          <span className="section-kicker">Bulletin dynamique</span>
          <h1>Répondez aux 12 questions</h1>
          <p>Les partis sont volontairement masqués pendant le vote. Vous répondez aux idées, pas aux étiquettes.</p>
        </div>
        <div className="progress-wrap"><strong>{adopted}/12 idées au-dessus de 50</strong><ProgressBar value={(adopted / axes.length) * 100} /></div>
      </section>
      <p className="maquette-note"><strong>Maquette :</strong> les barres “résultat à 20h” et “application réelle” sont illustratives. Elles montrent la logique du futur bulletin dynamique.</p>
      <section className="axis-grid">{axes.map(axis => <AxisCard key={axis.id} axis={axis} value={answers[axis.id]} onChange={setAnswer} />)}</section>
      <div className="actions"><button className="btn primary" onClick={showResults}>Voir mon diagnostic démocratique</button></div>
    </main>
  );
}

function ResultPage({ answers, reset, chooseParty }) {
  const matching = useMemo(() => computeMatching(answers), [answers]);
  const gaps = useMemo(() => computeDemocraticGaps(answers), [answers]);
  const winner = matching[0];
  const weakGaps = gaps.filter(gap => gap.weakCoverage);
  const partialGaps = gaps.filter(gap => gap.partialCoverage);
  return (
    <main className="page">
      <TopNav onReset={reset} />
      <section className="panel result-hero">
        <div>
          <span className="section-kicker">Résultat</span>
          <h1>Votre diagnostic démocratique</h1>
          <p>Le résultat montre le parti le plus proche, mais aussi les sujets où l’offre politique paraît insuffisante.</p>
        </div>
        <div className="winner" style={{ '--party': winner.color }}>
          <span>Parti le plus proche</span><strong>{winner.name}</strong><b>{winner.match}%</b>
        </div>
      </section>

      <section className="diagnostic-grid">
        <article className="diagnostic-card ok"><strong>{axes.length - partialGaps.length - weakGaps.length}</strong><span>Sujets représentés correctement</span></article>
        <article className="diagnostic-card partial"><strong>{partialGaps.length}</strong><span>Sujets partiellement couverts</span></article>
        <article className="diagnostic-card alert"><strong>{weakGaps.length}</strong><span>Angles morts démocratiques</span></article>
      </section>

      {weakGaps.length > 0 && (
        <section className="democratic-alert">
          <h2>⚠️ Angle mort démocratique détecté</h2>
          <p>Certaines attentes fortes de votre vote ne sont pas clairement couvertes par les partis analysés. Ce n’est pas un détail : cela signale un vide possible dans l’offre politique actuelle.</p>
          <div className="alert-list">
            {weakGaps.map(gap => <article key={gap.axis.id}><strong>{gap.axis.name}</strong><span>Aucun parti ne couvre clairement cette attente. Parti le moins éloigné : {gap.best.name}, couverture faible / partielle.</span></article>)}
          </div>
        </section>
      )}

      <section className="panel party-list">
        <h2>Classement de proximité</h2>
        <p className="soft">Calcul indicatif : distance entre vos curseurs et les positions estimées des partis, pondérée par l’intensité de vos réponses et le niveau de documentation.</p>
        {matching.map((party, index) => <div className="party-row" key={party.id} style={{ '--party': party.color }}><span className="rank">{index + 1}</span><strong>{party.name}</strong><ProgressBar value={party.match} color={party.color} /><b>{party.match}%</b></div>)}
      </section>

      <section className="tracking-panel">
        {gaps.map(gap => <article className={`track-card ${gap.weakCoverage ? 'is-alert' : gap.partialCoverage ? 'is-partial' : ''}`} key={gap.axis.id}>
          <div className="track-title"><span>{gap.axis.icon}</span><div><strong>{gap.axis.name}</strong><small>{gap.axis.question}</small></div></div>
          <div className="track-line"><span>Votre vote</span><b>{gap.answer}/100</b><ProgressBar value={gap.answer} color="#ffffff" kind="personal" /></div>
          <div className="track-line"><span>Résultat à 20h</span><b>{gap.collective}/100</b><ProgressBar value={gap.collective} color="#38bdf8" /></div>
          <div className="track-line"><span>Application réelle</span><b>{simulatedExecution(gap.axis.id, gap.collective)}%</b><ProgressBar value={simulatedExecution(gap.axis.id, gap.collective)} color="#22c55e" /></div>
          {gap.weakCoverage && <p className="axis-warning">Aucun parti ne couvre clairement cette question essentielle.</p>}
        </article>)}
      </section>

      <div className="actions"><button className="btn muted" onClick={reset}>Recommencer</button><button className="btn primary" onClick={chooseParty}>Choisir un vecteur politique</button></div>
    </main>
  );
}

function FinalVote({ answers, reset }) {
  const matching = useMemo(() => computeMatching(answers), [answers]);
  return (
    <main className="page">
      <TopNav onReset={reset} />
      <section className="panel"><span className="section-kicker">Simulation</span><h1>Choisir son vecteur politique</h1><p>Dans le système actuel, on vote encore pour un parti. Mais le vote par idées permet de comprendre ce que ce parti porte vraiment — ou ne porte pas.</p></section>
      <section className="vote-grid">{matching.map(party => <article className="vote-card" key={party.id} style={{ '--party': party.color }}><span className="party-dot" /><strong>{party.name}</strong><em>Proximité calculée : {party.match}%</em></article>)}</section>
      <div className="actions"><a className="btn primary" href="../">Retour au site Doctrine</a></div>
    </main>
  );
}

export default function App() {
  const [screen, setScreen] = useState('intro');
  const [answers, setAnswers] = useState(START_ANSWERS);
  function setAnswer(axisId, value) { setAnswers(prev => ({ ...prev, [axisId]: value })); }
  function reset() { setAnswers(START_ANSWERS); setScreen('intro'); }
  if (screen === 'intro') return <Intro start={() => setScreen('questions')} />;
  if (screen === 'questions') return <Questionnaire answers={answers} setAnswer={setAnswer} showResults={() => setScreen('results')} reset={reset} />;
  if (screen === 'results') return <ResultPage answers={answers} reset={reset} chooseParty={() => setScreen('final')} />;
  return <FinalVote answers={answers} reset={reset} />;
}
