# Bulletin de vote du futur proche — Prototype V8

Prototype React/Vite basé sur la maquette V6.5, migré vers les axes V7.3 et la matrice V7.3 bis.

## Installation

```bash
npm install
npm run dev
```

## Build GitHub

```bash
npm run build
```

Le dossier `dist/` généré peut être publié sur GitHub Pages.

## Contenu

- 12 questions V7.3
- Curseur premium dynamique
- Textes pédagogiques dynamiques
- Matching Manhattan
- Top 4 partis
- IC moyen et axes utilisés
- Mode futur / 3 barres en option
