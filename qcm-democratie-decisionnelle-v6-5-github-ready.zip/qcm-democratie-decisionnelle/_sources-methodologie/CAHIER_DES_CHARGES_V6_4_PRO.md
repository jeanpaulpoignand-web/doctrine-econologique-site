# Cahier des charges V6.4 Pro

## Principes
- Ne plus présenter l’outil comme un simple QCM.
- Parler de bulletin citoyen dynamique ou bulletin décisionnel.
- Garder les partis masqués pendant le vote.
- Conserver les trois barres : blanc = vote citoyen, bleu = résultat collectif, vert = application réelle.
- Rendre les angles morts démocratiques fortement visibles.

## Entrées futures du Pilier XIII
1. Et si on votait différemment ? — bulletin dynamique actuel.
2. Et si on avait voté différemment ? — module contrefactuel futur, avec cas déjà travaillés : Jean-Marie Le Pen 2007 et Jean-Luc Mélenchon 2017.

## À faire ensuite
- Intégrer une carte Pilier XIII animée sur la page principale.
- Ajouter un visuel billet/bulletin avec pilier antique en filigrane.
- Brancher un système de retours citoyens.
- Auditer la matrice partis axe par axe avec sources.
