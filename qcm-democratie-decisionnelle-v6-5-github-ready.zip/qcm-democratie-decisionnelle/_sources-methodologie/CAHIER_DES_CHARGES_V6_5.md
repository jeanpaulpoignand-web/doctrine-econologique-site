# Cahier des charges V6.5

## Problème identifié
Les tests de la V6.4 montrent un biais possible : un utilisateur peut comprendre que “tout à droite” favorise systématiquement les partis souverainistes/de droite, “tout à gauche” la gauche, et “au milieu” les partis de gouvernement.

## Correction
Alterner l’orientation des curseurs. Certaines questions placent la réponse souveraine/productive/exigeante à gauche, d’autres à droite. L’utilisateur doit donc lire chaque question.

## Effet attendu
- Réduction du vote mécanique.
- Réduction des critiques sur un éventuel biais partisan.
- Meilleure robustesse du bulletin citoyen.
- Matching toujours cohérent grâce à l’inversion simultanée des positions partisanes sur les axes concernés.

## Correction UX
Le passage aux résultats doit remonter systématiquement en haut de page, notamment sur iPad/Safari.
