# Méthode V6.3

Cette maquette ne demande pas d'abord à l'utilisateur pour quel parti il vote. Elle demande sa position sur 12 problèmes concrets.

Les partis sont masqués pendant le vote pour éviter un biais de réponse. Le matching partisan n'apparaît qu'à la fin.

Chaque question affiche trois niveaux :
1. votre vote personnel (barre blanche) ;
2. le résultat collectif à 20h (barre bleue, simulée dans la maquette) ;
3. l'application réelle des engagements (barre verte, simulée dans la maquette).

La finalité n'est pas seulement de désigner un parti proche, mais aussi de rendre visibles les sujets essentiels qui ne sont pas réellement couverts par l'offre politique actuelle.
