# Audit fonctionnel V8 — 2026-05-31

## Vérifications effectuées

- 12 axes V7.3 intégrés.
- Positions de partis importées depuis la matrice V7.3 bis.
- Scoring Manhattan : `100 - |réponse - position parti|`.
- Exclusion prévue des positions IC0.
- Top 4 des proximités affiché.
- Axes de convergence et divergence affichés.
- Texte pédagogique fixe + texte dynamique selon le curseur.
- Curseur premium : jeton circulaire, halo lumineux, agrandissement au toucher.
- Couleurs dynamiques : bleu côté pôle A, orange côté pôle B, neutre au centre.
- Mode futur affiché comme démonstration conceptuelle.
- Partis masqués pendant les 12 questions.

## Points non inclus dans cette livraison

- La page complète des sources détaillées par cellule n’est pas encore déployée en interface ; les métadonnées sont déjà présentes dans `src/data.js`.
- La publication GitHub Pages nécessite de construire le projet avec `npm install` puis `npm run build`, ou de pousser les sources et laisser le workflow produire le build.

## Statut

Prototype V8 prêt pour test humain et intégration GitHub.
