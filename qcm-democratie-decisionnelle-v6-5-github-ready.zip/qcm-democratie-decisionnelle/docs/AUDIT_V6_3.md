# Audit V6.3 — QCM Démocratie Décisionnelle

## Périmètre
- Refonte doctrinale des 12 questions.
- Suppression des partis visibles pendant le vote.
- Ajout des 3 barres par question : vote personnel, résultat collectif simulé, application réelle simulée.
- Ajout du diagnostic d'angle mort démocratique.
- Ajout des partis manquants, dont Nouvelle Énergie — David Lisnard.

## Discipline technique
- Aucun copier-coller manuel de gros fichier requis.
- Package React/Vite propre.
- Pas de Tailwind, pas de PostCSS.
- Pas de node_modules, pas de dist, pas de package-lock dans le ZIP.
- Base GitHub Pages : chemins Vite relatifs via base './'.

## Méthode
- Curseur 0–100.
- Au-dessus de 50 : l'idée est considérée adoptée par l'utilisateur.
- Matching : distance entre la réponse utilisateur et la position estimée des partis, pondérée par l'intensité et le niveau de documentation.
- Angle mort démocratique : signal visuel fort quand aucun parti ne couvre clairement une attente forte.

## Réserve
La matrice des positions reste indicative. Elle devra être auditée avec programmes, votes, déclarations et actions passées avant diffusion publique large.
