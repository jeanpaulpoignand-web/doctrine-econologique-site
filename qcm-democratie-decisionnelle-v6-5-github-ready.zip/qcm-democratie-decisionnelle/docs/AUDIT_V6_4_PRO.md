# Audit V6.4 Pro

## Contrôles effectués
- Base V6.3 stable conservée.
- Ajout du scroll automatique en haut lors des changements d’écran, notamment vers les résultats.
- Terminologie renforcée : “bulletin citoyen dynamique” au lieu de QCM en façade.
- Ajout d’un rappel visuel/pédagogique des trois barres : vote, résultat à 20h, application réelle.
- Ajout d’un bloc prospectif : “Et si on votait différemment ?” / “Et si on avait voté différemment ?”.
- Renforcement visuel des angles morts démocratiques.
- Ajout d’un filigrane de pilier civique sur l’écran d’accueil du bulletin.

## Limite assumée
Cette version modifie le bulletin décisionnel. L’intégration dans la page principale du site Doctrine / Pilier XIII devra être faite dans le dépôt du site principal, avec un composant ou une carte dédiée.
