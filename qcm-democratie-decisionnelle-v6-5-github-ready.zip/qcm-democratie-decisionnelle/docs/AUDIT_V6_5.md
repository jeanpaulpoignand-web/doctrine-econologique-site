# Audit V6.5 — Bulletin citoyen dynamique

## Objectif
Réduire les biais de réponse mécanique et fiabiliser l’expérience utilisateur.

## Changements intégrés
- Passage de version à 6.5.0.
- Scroll renforcé vers le haut lors du passage aux résultats et à l’écran final.
- Ajout d’un helper `scrollToTop()` avec double appel de sécurité pour Safari/iPad.
- Ajout d’une règle méthodologique visible : curseurs anti-biais.
- Inversion partielle de 6 axes pour éviter que “tout à droite” corresponde toujours au même bloc politique.
- Positions des partis inversées sur les axes concernés pour conserver la cohérence du matching.

## Axes inversés
- Santé / déserts médicaux.
- Agriculture locale.
- Évasion fiscale.
- Immigration / intégration.
- Éducation.
- Argent public / dette.

## Contrôles
- `package.json` propre.
- `vite.config.js` avec `base: './'`.
- Pas de Tailwind/PostCSS.
- Pas de `node_modules`, pas de `dist`, pas de `package-lock.json` dans le ZIP final.
- Build local obligatoire avant livraison.
