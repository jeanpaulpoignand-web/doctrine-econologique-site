export const parties = [
  {
    "id": "rn",
    "name": "Rassemblement National",
    "short": "RN",
    "color": "#2563eb"
  },
  {
    "id": "reconquete",
    "name": "Reconquête",
    "short": "Reconquête",
    "color": "#7f1d1d"
  },
  {
    "id": "dlf",
    "name": "Debout la France",
    "short": "DLF",
    "color": "#2563eb"
  },
  {
    "id": "upr",
    "name": "UPR",
    "short": "UPR",
    "color": "#0f766e"
  },
  {
    "id": "patriotes",
    "name": "Les Patriotes",
    "short": "Patriotes",
    "color": "#0284c7"
  },
  {
    "id": "rep_souveraine",
    "name": "République Souveraine",
    "short": "RS",
    "color": "#9333ea"
  },
  {
    "id": "lr",
    "name": "Les Républicains",
    "short": "LR",
    "color": "#0066cc"
  },
  {
    "id": "nouvelle_energie",
    "name": "Nouvelle Énergie — David Lisnard",
    "short": "Nouvelle Énergie",
    "color": "#f59e0b"
  },
  {
    "id": "renaissance",
    "name": "Renaissance / Ensemble",
    "short": "Renaissance",
    "color": "#fb923c"
  },
  {
    "id": "ps",
    "name": "Parti Socialiste",
    "short": "PS",
    "color": "#e11d48"
  },
  {
    "id": "lfi",
    "name": "La France Insoumise",
    "short": "LFI",
    "color": "#dc2626"
  },
  {
    "id": "pcf",
    "name": "Parti Communiste Français",
    "short": "PCF",
    "color": "#b91c1c"
  },
  {
    "id": "eelv",
    "name": "Les Écologistes / EELV",
    "short": "EELV",
    "color": "#16a34a"
  },
  {
    "id": "generations",
    "name": "Génération·s",
    "short": "Génération·s",
    "color": "#ec4899"
  }
];

export const axes = [
  {
    "id": "energie",
    "icon": "⚡",
    "name": "Énergie",
    "question": "Quelle priorité énergétique la France doit-elle privilégier ?",
    "left": "Énergie pilotable et maîtrise nationale",
    "right": "Renouvelables variables et transformation rapide du mix",
    "measure": "Le curseur mesure l'importance accordée à la maîtrise nationale des moyens de production énergétique par rapport à la transformation rapide du mix énergétique.",
    "leftSoft": "Vous privilégiez plutôt une énergie pilotable, disponible quand le pays en a besoin, avec une maîtrise nationale plus forte.",
    "leftStrong": "Vous privilégiez fortement une énergie pilotable, maîtrisée nationalement et capable de produire au moment où le pays en a besoin.",
    "center": "Vous recherchez un équilibre entre maîtrise nationale de l’énergie et développement des renouvelables.",
    "rightSoft": "Vous privilégiez plutôt le développement du solaire, de l’éolien, du stockage et l’adaptation progressive des usages.",
    "rightStrong": "Vous privilégiez fortement une transformation rapide du mix énergétique vers les renouvelables variables et les nouveaux usages.",
    "leftKeywords": [
      "Nucléaire",
      "Hydraulique",
      "Biométhane",
      "Pilotable",
      "Souveraineté"
    ],
    "rightKeywords": [
      "Solaire",
      "Éolien",
      "Stockage",
      "Réseau",
      "Usages"
    ],
    "positions": {
      "rn": 10,
      "reconquete": 12,
      "lr": 15,
      "renaissance": 35,
      "ps": 65,
      "lfi": 90,
      "pcf": 55,
      "eelv": 95,
      "upr": 25,
      "patriotes": 5,
      "dlf": 20,
      "rep_souveraine": 8,
      "nouvelle_energie": 20,
      "generations": 80
    },
    "ic": {
      "rn": 4,
      "reconquete": 3,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 3,
      "eelv": 4,
      "upr": 3,
      "patriotes": 4,
      "dlf": 3,
      "rep_souveraine": 3,
      "nouvelle_energie": 3,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN législatives 2024",
        "date": "2024-06",
        "link": "https://rassemblementnational.fr/documents/202406-programme.pdf",
        "comment": "Nucléaire fort; moratoire ENR; démantèlement éoliennes"
      },
      "reconquete": {
        "ic": "IC3",
        "source": "Site officiel reconquete.fr + déclarations Zemmour",
        "date": "2023-11",
        "link": "https://www.reconquete.fr",
        "comment": "Nucléaire fort; contre ENR subventionnés; position stable"
      },
      "lr": {
        "ic": "IC4",
        "source": "Programme LR 2022 + SFEN réponse questionnaire 2024",
        "date": "2024-06",
        "link": "https://www.sfen.org",
        "comment": "Nucléaire central; ENR complément; politique Wauquiez"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Programme Ensemble législatives 2024",
        "date": "2024-06",
        "link": "https://parti-renaissance.fr",
        "comment": "Mix nucléaire-ENR; 6+8 réacteurs; transition équilibrée"
      },
      "ps": {
        "ic": "IC4",
        "source": "Programme NFP juin 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Nucléaire transition; ENR massif; ambiguïté interne"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Sortie nucléaire; 100% ENR 2045; plan Mélenchon"
      },
      "pcf": {
        "ic": "IC3",
        "source": "Programme PCF 2022 + NFP 2024",
        "date": "2024-06",
        "link": "https://www.pcf.fr",
        "comment": "Nucléaire transitoire accepté; ENR prioritaire; position ambiguë"
      },
      "eelv": {
        "ic": "IC4",
        "source": "Programme EELV européennes 2024",
        "date": "2024-06",
        "link": "https://lesecologistes.eu",
        "comment": "Sortie nucléaire; 100% ENR; position centrale du parti"
      },
      "upr": {
        "ic": "IC3",
        "source": "Programme présidentiel UPR 2022 (upr.fr)",
        "date": "2022-01",
        "link": "https://upr.fr/actualites/programme-presidentiel-2022",
        "comment": "Nucléaire partiel (fusion R&D prioritaire); ENR secondaire; pas de prise de position franche sur fission"
      },
      "patriotes": {
        "ic": "IC4",
        "source": "Grandes orientations Les Patriotes (les-patriotes.fr)",
        "date": "2024-01",
        "link": "https://www.candidatspresidentielles2027.fr/candidats/florian-philippot",
        "comment": "Nucléaire + hydroélectricité massivement; arrêt éoliennes terre/mer; sortie marché européen électricité"
      },
      "dlf": {
        "ic": "IC3",
        "source": "Programme présidentiel DLF 2022 + Wikipedia",
        "date": "2022-01",
        "link": "https://fr.wikipedia.org/wiki/Debout_la_France",
        "comment": "Nucléaire maintenu; fermeture centrales vieillissantes; R&D 4e génération; ENR complément raisonnable"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "Wikipedia RS + programme 50 propositions",
        "date": "2022-01",
        "link": "https://fr.wikipedia.org/wiki/R%C3%A9publique_souveraine",
        "comment": "Réinvestissement nucléaire; renationalisation filière énergétique; transition écologique planifiée"
      },
      "nouvelle_energie": {
        "ic": "IC3",
        "source": "Programme NE unenouvelleenergie.fr + Carbon Brief",
        "date": "2025-11",
        "link": "https://www.unenouvelleenergie.fr/notre-programme/",
        "comment": "Peu de position directe énergie publiée; libéral économique; marché; nucléaire probable mais non explicit"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon présidentielle 2017",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "Sortie nucléaire accélérée; ENR massif; position cohérente avec EELV — IC2 peu de sources récentes"
      }
    }
  },
  {
    "id": "sante",
    "icon": "🏥",
    "name": "Santé / déserts médicaux",
    "question": "Comment réduire les déserts médicaux ?",
    "left": "Régulation territoriale des soins",
    "right": "Liberté d'installation et attractivité",
    "measure": "Le curseur mesure l'importance accordée à la régulation territoriale des soins par rapport à la liberté d'installation des professionnels de santé.",
    "leftSoft": "Vous privilégiez plutôt une organisation plus forte de la présence médicale sur tout le territoire.",
    "leftStrong": "Vous privilégiez fortement la régulation territoriale pour garantir une présence médicale dans les zones sous-dotées.",
    "center": "Vous recherchez un équilibre entre liberté d'installation et couverture médicale effective.",
    "rightSoft": "Vous privilégiez plutôt les incitations, les revenus, les conditions de travail et la formation.",
    "rightStrong": "Vous privilégiez fortement la liberté d'installation et l'attractivité plutôt que la contrainte territoriale.",
    "leftKeywords": [
      "Territoires",
      "Conventionnement",
      "Présence médicale",
      "État"
    ],
    "rightKeywords": [
      "Liberté",
      "Attractivité",
      "Revenus",
      "Formation"
    ],
    "positions": {
      "rn": 15,
      "reconquete": 70,
      "lr": 60,
      "renaissance": 65,
      "ps": 25,
      "lfi": 10,
      "pcf": 8,
      "eelv": 30,
      "upr": 5,
      "patriotes": 20,
      "dlf": 20,
      "rep_souveraine": 10,
      "nouvelle_energie": 75,
      "generations": 20
    },
    "ic": {
      "rn": 4,
      "reconquete": 2,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 4,
      "eelv": 4,
      "upr": 3,
      "patriotes": 3,
      "dlf": 3,
      "rep_souveraine": 3,
      "nouvelle_energie": 4,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN 2024 + vote Garot mai 2025",
        "date": "2025-05",
        "link": "https://www.banquedesterritoires.fr/deserts-medicaux-chacun-sa-proposition",
        "comment": "Régulation coercitive acceptée; RN s'est abstenu sur loi Garot"
      },
      "reconquete": {
        "ic": "IC2",
        "source": "Zemmour interviews 2022 CNews",
        "date": "2022-03",
        "link": "https://www.youtube.com/watch?v=ZemmourSante2022",
        "comment": "Liberté installation médecins; contre régulation contraignante"
      },
      "lr": {
        "ic": "IC4",
        "source": "Proposition loi Mouiller mai 2025 (Sénat LR)",
        "date": "2025-05",
        "link": "https://www.banquedesterritoires.fr/deserts-medicaux-chacun-sa-proposition",
        "comment": "Contre régulation contraignante; incitation plutôt qu'obligation"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Pacte Bayrou déserts médicaux avr 2025",
        "date": "2025-04",
        "link": "https://www.vie-publique.fr/eclairage/24080-sante-quelle-politique-publique-contre-les-deserts-medicaux",
        "comment": "Incitation prioritaire; refus contrainte installation"
      },
      "ps": {
        "ic": "IC4",
        "source": "Vote Garot PS mai 2025 (Banque Territoires)",
        "date": "2025-05",
        "link": "https://www.banquedesterritoires.fr/deserts-medicaux-chacun-sa-proposition",
        "comment": "PS co-porteur loi Garot; régulation installation"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Régulation forte installation; service public médecin"
      },
      "pcf": {
        "ic": "IC4",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "Service public médecine; salariat médecins; régulation forte"
      },
      "eelv": {
        "ic": "IC4",
        "source": "Programme EELV 2022",
        "date": "2022-01",
        "link": "https://lesecologistes.eu",
        "comment": "Régulation partielle installation; mixte incitation/contrainte"
      },
      "upr": {
        "ic": "IC3",
        "source": "Programme présidentiel UPR 2022 (upr.fr)",
        "date": "2022-01",
        "link": "https://upr.fr/actualites/programme-presidentiel-2022",
        "comment": "Réouvrir 30 000 lits hôpital public; cartographie déserts médicaux; majoration 20% actes zones rurales"
      },
      "patriotes": {
        "ic": "IC3",
        "source": "Grandes orientations Les Patriotes",
        "date": "2024-01",
        "link": "https://www.candidatspresidentielles2027.fr/candidats/florian-philippot",
        "comment": "Médecine de proximité rétablie; liberté vaccinale; sortie OMS; peu de détail sur installation"
      },
      "dlf": {
        "ic": "IC3",
        "source": "YouTube DLF mars 2026 — face citoyens patriotes",
        "date": "2026-03",
        "link": "https://www.youtube.com/watch?v=IzkpvEQBxl4",
        "comment": "Déserts médicaux: solution formation + incitation; pas régulation contraignante"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "Lettre RS janv 2024 + LCI fév 2022 Kuzmanovic (republique-souveraine.fr)",
        "date": "2024-01",
        "link": "https://data.over-blog-kiwi.com/1/44/95/69/20240207/ob_819ffc_repulique-souveraine-raison-peuple-01.pdf",
        "comment": "100% Sécu priorité; fin complémentaires inégalitaires; contrainte installation médecins assumée; inégalités géographiques d'accès documentées"
      },
      "nouvelle_energie": {
        "ic": "IC4",
        "source": "Le Figaro — Lisnard plan santé mai 2026",
        "date": "2026-05",
        "link": "https://www.lefigaro.fr/politique/sante-david-lisnard-devoile-son-plan-d-action-rapide-inspire-des-ordonnances-de-1958-20260505",
        "comment": "Réorganisation hôpital; liberté prescription; contre régulation coercitive; loi programmation santé"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon 2017",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "Service public médecine renforcé; déserts médicaux = priorité — IC2 sources peu récentes"
      }
    }
  },
  {
    "id": "agriculture",
    "icon": "🌾",
    "name": "Agriculture",
    "question": "Quelle agriculture faut-il protéger en priorité ?",
    "left": "Souveraineté alimentaire et protection des producteurs français",
    "right": "Agriculture ouverte et compétitivité internationale",
    "measure": "Le curseur mesure la priorité accordée à la souveraineté alimentaire française par rapport à l'ouverture des marchés agricoles.",
    "leftSoft": "Vous privilégiez plutôt la protection des producteurs français, les circuits courts et la réduction des importations évitables.",
    "leftStrong": "Vous privilégiez fortement la souveraineté alimentaire, les clauses miroirs et la protection des producteurs français.",
    "center": "Vous recherchez un équilibre entre production française et échanges agricoles internationaux.",
    "rightSoft": "Vous privilégiez plutôt l'adaptation des filières agricoles à la concurrence et aux marchés mondiaux.",
    "rightStrong": "Vous privilégiez fortement une agriculture ouverte aux échanges internationaux et à la compétitivité de marché.",
    "leftKeywords": [
      "Producteurs",
      "France",
      "Circuits courts",
      "Clauses miroirs"
    ],
    "rightKeywords": [
      "Échanges",
      "Compétitivité",
      "Marchés",
      "Export"
    ],
    "positions": {
      "rn": 12,
      "reconquete": 20,
      "lr": 30,
      "renaissance": 55,
      "ps": 40,
      "lfi": 30,
      "pcf": 20,
      "eelv": 45,
      "upr": 8,
      "patriotes": 5,
      "dlf": 10,
      "rep_souveraine": 8,
      "nouvelle_energie": 55,
      "generations": 45
    },
    "ic": {
      "rn": 4,
      "reconquete": 3,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 3,
      "eelv": 4,
      "upr": 4,
      "patriotes": 4,
      "dlf": 4,
      "rep_souveraine": 3,
      "nouvelle_energie": 4,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN 2024",
        "date": "2024-06",
        "link": "https://rassemblementnational.fr/documents/202406-programme.pdf",
        "comment": "Souveraineté alimentaire; préférence nationale achats publics"
      },
      "reconquete": {
        "ic": "IC3",
        "source": "Programme présidentiel Zemmour 2022",
        "date": "2022-01",
        "link": "https://www.reconquete.fr/programme",
        "comment": "Souveraineté alimentaire; circuits courts; contre accords libre-échange"
      },
      "lr": {
        "ic": "IC4",
        "source": "Programme LR législatives 2024",
        "date": "2024-06",
        "link": "https://www.republicains.fr",
        "comment": "Souveraineté alimentaire; refus Mercosur; clauses miroirs"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Programme Ensemble 2024",
        "date": "2024-06",
        "link": "https://parti-renaissance.fr",
        "comment": "Libre-échange UE + clauses miroirs; ni extrême"
      },
      "ps": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Souveraineté alimentaire + commerce équitable; position mixte"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Souveraineté alimentaire; aides agriculteurs; fin libre-échange"
      },
      "pcf": {
        "ic": "IC3",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "Souveraineté alimentaire; contre OMC libre-échange; coopératives"
      },
      "eelv": {
        "ic": "IC4",
        "source": "Programme EELV 2022",
        "date": "2022-01",
        "link": "https://lesecologistes.eu",
        "comment": "Agroécologie; circuits courts; commerce équitable international"
      },
      "upr": {
        "ic": "IC4",
        "source": "YouTube Asselineau agriculture mars 2026",
        "date": "2026-03",
        "link": "https://www.youtube.com/watch?v=p5ksDgcnHt8",
        "comment": "Prix planchers agriculteurs; Frexit = fin libre-échange PAC; contre Mercosur/CETA; souveraineté alimentaire centrale"
      },
      "patriotes": {
        "ic": "IC4",
        "source": "Grandes orientations Les Patriotes",
        "date": "2024-01",
        "link": "https://www.candidatspresidentielles2027.fr/candidats/florian-philippot",
        "comment": "PAC remplacée par politique agricole française; souveraineté alimentaire; circuits courts; bio; permaculture"
      },
      "dlf": {
        "ic": "IC4",
        "source": "Wikipedia DLF — PAC et agriculture",
        "date": "2006-05",
        "link": "https://fr.wikipedia.org/wiki/Debout_la_France",
        "comment": "Restaurer aides directes agriculteurs; supprimer PAC UE; souveraineté alimentaire prioritaire"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "Wikipedia RS — programme économique",
        "date": "2022-01",
        "link": "https://fr.wikipedia.org/wiki/R%C3%A9publique_souveraine",
        "comment": "Réindustrialisation planifiée; souveraineté alimentaire; contre libre-échange; inspiré CNR"
      },
      "nouvelle_energie": {
        "ic": "IC4",
        "source": "Programme NE agriculture — unenouvelleenergie.fr",
        "date": "2026-02",
        "link": "https://www.unenouvelleenergie.fr/notre-programme/agriculture/",
        "comment": "Libérer production agricole; clauses miroirs; NTG autorisées; PAC recentrée souveraineté mais marché"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon 2017 — agriculture bio",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "Agroécologie; circuits courts; commerce équitable; transition vers bio — IC2"
      }
    }
  },
  {
    "id": "industrie",
    "icon": "🏭",
    "name": "Emploi / industrie",
    "question": "Comment reconstruire l'emploi productif en France ?",
    "left": "Réindustrialisation pilotée et protection productive",
    "right": "Compétitivité ouverte et attractivité économique",
    "measure": "Le curseur mesure l'importance accordée à la réindustrialisation pilotée par rapport à une économie plus ouverte aux capitaux et aux chaînes de valeur mondiales.",
    "leftSoft": "Vous privilégiez plutôt la relocalisation, les filières stratégiques et l'emploi productif en France.",
    "leftStrong": "Vous privilégiez fortement une politique industrielle pilotée, la commande publique et la protection des secteurs stratégiques.",
    "center": "Vous recherchez un équilibre entre intervention productive et attractivité économique.",
    "rightSoft": "Vous privilégiez plutôt l'attraction des capitaux, l'allègement des contraintes et l'insertion dans les chaînes mondiales.",
    "rightStrong": "Vous privilégiez fortement la compétitivité ouverte, la liberté des entreprises et l’attractivité internationale.",
    "leftKeywords": [
      "Relocalisation",
      "Industrie",
      "Commande publique",
      "Filières"
    ],
    "rightKeywords": [
      "Capitaux",
      "Compétitivité",
      "Attractivité",
      "Marché mondial"
    ],
    "positions": {
      "rn": 18,
      "reconquete": 25,
      "lr": 40,
      "renaissance": 50,
      "ps": 35,
      "lfi": 15,
      "pcf": 10,
      "eelv": 55,
      "upr": 5,
      "patriotes": 8,
      "dlf": 15,
      "rep_souveraine": 5,
      "nouvelle_energie": 70,
      "generations": 40
    },
    "ic": {
      "rn": 4,
      "reconquete": 3,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 3,
      "eelv": 3,
      "upr": 3,
      "patriotes": 4,
      "dlf": 4,
      "rep_souveraine": 3,
      "nouvelle_energie": 4,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN 2024",
        "date": "2024-06",
        "link": "https://rassemblementnational.fr/documents/202406-programme.pdf",
        "comment": "Réindustrialisation dirigiste; protectionnisme ciblé"
      },
      "reconquete": {
        "ic": "IC3",
        "source": "Programme présidentiel Zemmour 2022",
        "date": "2022-01",
        "link": "https://www.reconquete.fr/programme",
        "comment": "Réindustrialisation; protectionnisme; contre délocalisations"
      },
      "lr": {
        "ic": "IC4",
        "source": "Programme LR 2022",
        "date": "2022-01",
        "link": "https://www.republicains.fr",
        "comment": "Réindustrialisation mais marché; moins interventionniste que gauche"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Programme Ensemble 2024",
        "date": "2024-06",
        "link": "https://parti-renaissance.fr",
        "comment": "Réindustrialisation + marché; France 2030; équilibre"
      },
      "ps": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Réindustrialisation publique; planification douce"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Planification; nationalisations; SMIC 1600€; bifurcation"
      },
      "pcf": {
        "ic": "IC3",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "Nationalisations; planification communiste; État omniprésent"
      },
      "eelv": {
        "ic": "IC3",
        "source": "Programme EELV 2022",
        "date": "2022-01",
        "link": "https://lesecologistes.eu",
        "comment": "Économie verte; emplois durables; transition industrielle"
      },
      "upr": {
        "ic": "IC3",
        "source": "Programme UPR 2022 + Wikipedia UPR",
        "date": "2022-01",
        "link": "https://fr.wikipedia.org/wiki/Union_populaire_r%C3%A9publicaine_(2007)",
        "comment": "Nationalisations EDF/SNCF/autoroutes; planification CNR 1944; État omniprésent dans stratégique"
      },
      "patriotes": {
        "ic": "IC4",
        "source": "Grandes orientations + CNews avr 2025",
        "date": "2025-04",
        "link": "https://www.dailymotion.com/video/x9hixww",
        "comment": "Planification économique souveraine; protectionnisme ciblé; réindustrialisation; Frexit = relocalisation"
      },
      "dlf": {
        "ic": "IC4",
        "source": "Wikipedia DLF — programme économique",
        "date": "2006-05",
        "link": "https://fr.wikipedia.org/wiki/Debout_la_France",
        "comment": "Protectionnisme intelligent; produire français; bonus fiscal entreprises locales; relocaliser 1M emplois"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "YouTube Kuzmanovic jan 2022",
        "date": "2022-01",
        "link": "https://www.youtube.com/watch?v=4IOkNIhQ5oI",
        "comment": "Planification étatique; nationalisations stratégiques; réindustrialisation; Frexit conditon"
      },
      "nouvelle_energie": {
        "ic": "IC4",
        "source": "Institut Diderot — Lisnard 'La droite en France'",
        "date": "2023-12",
        "link": "https://www.institutdiderot.fr/wp-content/uploads/2023/12/David-Lisnard-La-droite-en-france-Page.pdf",
        "comment": "Libéralisme économique; marché + État régalien; contrat travail unique; dérégulation"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon 2017 — revenu universel",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "Revenu universel 600€; économie services; moins industrialiste que PCF — IC2 sources datées"
      }
    }
  },
  {
    "id": "justice",
    "icon": "⚖️",
    "name": "Justice",
    "question": "Quelle priorité donner à la justice pénale ?",
    "left": "Exécution effective des peines",
    "right": "Individualisation et réinsertion",
    "measure": "Le curseur mesure l'importance accordée à l'exécution effective des peines par rapport à l'individualisation des sanctions et à la réinsertion.",
    "leftSoft": "Vous privilégiez plutôt une application plus rapide et plus réelle des peines prononcées.",
    "leftStrong": "Vous privilégiez fortement l’exécution effective des peines et le renforcement des moyens judiciaires et pénitentiaires.",
    "center": "Vous recherchez un équilibre entre sanction, prévention de la récidive et réinsertion.",
    "rightSoft": "Vous privilégiez plutôt l’adaptation des sanctions aux situations individuelles et le suivi des personnes condamnées.",
    "rightStrong": "Vous privilégiez fortement les alternatives, la réinsertion et l’individualisation pour réduire la récidive.",
    "leftKeywords": [
      "Peines",
      "Application",
      "Moyens",
      "Prison"
    ],
    "rightKeywords": [
      "Réinsertion",
      "Suivi",
      "Alternatives",
      "Récidive"
    ],
    "positions": {
      "rn": 8,
      "reconquete": 5,
      "lr": 15,
      "renaissance": 50,
      "ps": 65,
      "lfi": 80,
      "pcf": 75,
      "eelv": 78,
      "upr": 15,
      "patriotes": 12,
      "dlf": 15,
      "rep_souveraine": 20,
      "nouvelle_energie": 30,
      "generations": 72
    },
    "ic": {
      "rn": 4,
      "reconquete": 4,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 3,
      "eelv": 4,
      "upr": 3,
      "patriotes": 4,
      "dlf": 4,
      "rep_souveraine": 3,
      "nouvelle_energie": 3,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN 2024",
        "date": "2024-06",
        "link": "https://rassemblementnational.fr/documents/202406-programme.pdf",
        "comment": "Peines planchers; fin réductions automatiques; fermeté affichée"
      },
      "reconquete": {
        "ic": "IC4",
        "source": "Programme présidentiel Zemmour 2022",
        "date": "2022-01",
        "link": "https://www.reconquete.fr/programme",
        "comment": "Peines incompressibles; tolérance zéro; réouverture bagnes"
      },
      "lr": {
        "ic": "IC4",
        "source": "Programme LR 2022",
        "date": "2022-01",
        "link": "https://www.republicains.fr",
        "comment": "Peines planchers LR; exécution ferme; fermeté judiciaire"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Programme Ensemble 2024",
        "date": "2024-06",
        "link": "https://parti-renaissance.fr",
        "comment": "Entre fermeté et réinsertion; justice équilibrée"
      },
      "ps": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Réinsertion + alternatives peines; humanisation prison"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Réinsertion; alternatives carcérales; abrogation peines planchers"
      },
      "pcf": {
        "ic": "IC3",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "Justice réparatrice; abrogation peines planchers; réinsertion"
      },
      "eelv": {
        "ic": "IC4",
        "source": "Programme EELV 2022",
        "date": "2022-01",
        "link": "https://lesecologistes.eu",
        "comment": "Réinsertion centrale; abolition peines planchers; justice restaurative"
      },
      "upr": {
        "ic": "IC3",
        "source": "MonVote2027 — positions UPR vérifiées",
        "date": "2021-10",
        "link": "https://monvote2027.fr/candidat/asselineau",
        "comment": "Peines minimales récidivistes; emprisonnement même court pour violences; fermeté"
      },
      "patriotes": {
        "ic": "IC4",
        "source": "Grandes orientations Les Patriotes",
        "date": "2024-01",
        "link": "https://www.candidatspresidentielles2027.fr/candidats/florian-philippot",
        "comment": "Police de proximité; réforme justice mineurs; suppression réductions automatiques; peines planchers"
      },
      "dlf": {
        "ic": "IC4",
        "source": "Wikipedia DLF + 5 référendums 2012",
        "date": "2006-05",
        "link": "https://fr.wikipedia.org/wiki/Debout_la_France",
        "comment": "Réforme pénale référendum 2012; fermeté; inéligibilité à vie corruption; colonies pénales"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "Marianne sept 2021 + Figaro sept 2021 + Corse Net Infos — Kuzmanovic",
        "date": "2021-09",
        "link": "https://www.marianne.net/politique/entretien-georges-kuzmanovic-declare-sa-candidature-a-lelection-presidentielle",
        "comment": "Sécurité citée systématiquement; lutte pédocriminalité cause nationale quinquennat; fermeté judiciaire; laïcité stricte"
      },
      "nouvelle_energie": {
        "ic": "IC3",
        "source": "Programme NE sécurité unenouvelleenergie.fr",
        "date": "2025-11",
        "link": "https://www.unenouvelleenergie.fr/notre-programme/",
        "comment": "Soutien police; abaissement majorité pénale 16 ans; fermeté judiciaire"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon 2017",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "Réinsertion; alternatives carcérales; humanisation prison — IC2"
      }
    }
  },
  {
    "id": "fiscalite",
    "icon": "🧾",
    "name": "Évasion fiscale / optimisation",
    "question": "Comment traiter les profits créés en France mais déplacés fiscalement ailleurs ?",
    "left": "Fiscalité liée au lieu réel de création de valeur",
    "right": "Attractivité fiscale et cadre international existant",
    "measure": "Le curseur mesure l'importance accordée à la taxation des bénéfices créés en France par rapport au maintien du cadre fiscal international actuel.",
    "leftSoft": "Vous privilégiez plutôt une contribution plus forte en France lorsque la valeur est créée par le marché, le travail ou les infrastructures françaises.",
    "leftStrong": "Vous privilégiez fortement une fiscalité fondée sur le lieu réel de création de valeur et une lutte plus offensive contre l’optimisation.",
    "center": "Vous recherchez un équilibre entre souveraineté fiscale et coopération internationale.",
    "rightSoft": "Vous privilégiez plutôt la compétitivité fiscale et les cadres européens, OCDE et internationaux existants.",
    "rightStrong": "Vous privilégiez fortement l’attractivité fiscale et l’action dans les cadres internationaux déjà établis.",
    "leftKeywords": [
      "Valeur créée",
      "France",
      "Impôt",
      "Multinationales"
    ],
    "rightKeywords": [
      "Attractivité",
      "OCDE",
      "Europe",
      "Compétitivité fiscale"
    ],
    "positions": {
      "rn": 20,
      "reconquete": 70,
      "lr": 35,
      "renaissance": 45,
      "ps": 20,
      "lfi": 10,
      "pcf": 5,
      "eelv": 15,
      "upr": 5,
      "patriotes": 10,
      "dlf": 15,
      "rep_souveraine": 5,
      "nouvelle_energie": 72,
      "generations": 15
    },
    "ic": {
      "rn": 4,
      "reconquete": 2,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 4,
      "eelv": 4,
      "upr": 3,
      "patriotes": 3,
      "dlf": 4,
      "rep_souveraine": 3,
      "nouvelle_energie": 3,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN 2024",
        "date": "2024-06",
        "link": "https://rassemblementnational.fr/documents/202406-programme.pdf",
        "comment": "Lutte évasion fiscale; taxation superprofits; ISF partiel"
      },
      "reconquete": {
        "ic": "IC2",
        "source": "Zemmour interviews 2022",
        "date": "2022-03",
        "link": "https://www.reconquete.fr",
        "comment": "Hostile ISF rétabli; libéral sur fiscalité capital"
      },
      "lr": {
        "ic": "IC4",
        "source": "Programme LR 2022",
        "date": "2022-01",
        "link": "https://www.republicains.fr",
        "comment": "Lutte évasion fiscale; refus ISF; retenue modérée capital"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Programme Ensemble 2024",
        "date": "2024-06",
        "link": "https://parti-renaissance.fr",
        "comment": "Coopération fiscale UE; contre évasion mais pro libre circulation K"
      },
      "ps": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Harmonisation fiscale UE; contre évasion; ISF rétabli"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Taxe superprofits; ISF renforcé; coopération fiscale"
      },
      "pcf": {
        "ic": "IC4",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "Taxation extrême capital; fin paradis fiscaux; ISF maximal"
      },
      "eelv": {
        "ic": "IC4",
        "source": "Programme EELV 2022",
        "date": "2022-01",
        "link": "https://lesecologistes.eu",
        "comment": "Fin paradis fiscaux; ISF vert; harmonisation fiscale UE"
      },
      "upr": {
        "ic": "IC3",
        "source": "Programme UPR 2022 — IS progressif, superprofits",
        "date": "2022-01",
        "link": "https://upr.fr/actualites/programme-presidentiel-2022",
        "comment": "IS progressif; bénéfices FR taxés en FR; Frexit comme condition anti-évasion; nationalisations financières"
      },
      "patriotes": {
        "ic": "IC3",
        "source": "Grandes orientations + Wikipedia Les Patriotes",
        "date": "2024-01",
        "link": "https://fr.wikipedia.org/wiki/Les_Patriotes_(parti_politique)",
        "comment": "ISF rétabli; contre évasion fiscale; Frexit = fin libre circulation capitaux hors France"
      },
      "dlf": {
        "ic": "IC4",
        "source": "Wikipedia DLF — fiscalité",
        "date": "2006-05",
        "link": "https://fr.wikipedia.org/wiki/Debout_la_France",
        "comment": "Impôt citoyenneté Français étranger; tranche IR 50% hauts revenus; taxe Tobin; lutte évasion"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "Wikipedia RS — oligarchie financière",
        "date": "2022-01",
        "link": "https://fr.wikipedia.org/wiki/R%C3%A9publique_souveraine",
        "comment": "Lutte oligarchie financière; mondialisation refusée; Frexit = souveraineté monétaire/budgétaire"
      },
      "nouvelle_energie": {
        "ic": "IC3",
        "source": "Institut Diderot Lisnard 2023",
        "date": "2023-12",
        "link": "https://www.institutdiderot.fr/wp-content/uploads/2023/12/David-Lisnard-La-droite-en-france-Page.pdf",
        "comment": "Libéral sur fiscalité capital; réduction IS; contre ISF; libre organisation fiscale"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon 2017",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "ISF; taxation capital; lutte évasion fiscale; harmonisation UE — IC2"
      }
    }
  },
  {
    "id": "immigration",
    "icon": "👥",
    "name": "Immigration",
    "question": "Quelle orientation migratoire la France doit-elle choisir ?",
    "left": "Maîtrise stricte des flux migratoires",
    "right": "Accueil plus ouvert et droits élargis",
    "measure": "Le curseur mesure l'importance accordée à la maîtrise des flux migratoires par rapport à une politique d'accueil plus ouverte.",
    "leftSoft": "Vous privilégiez plutôt le contrôle des entrées, la capacité d’accueil et l’intégration réelle.",
    "leftStrong": "Vous privilégiez fortement la maîtrise stricte des flux migratoires et la protection des équilibres sociaux.",
    "center": "Vous recherchez un équilibre entre contrôle, accueil et intégration.",
    "rightSoft": "Vous privilégiez plutôt l’accueil, les régularisations, les droits sociaux et une solidarité plus universaliste.",
    "rightStrong": "Vous privilégiez fortement une politique d’accueil plus ouverte et des droits élargis.",
    "leftKeywords": [
      "Contrôle",
      "Frontières",
      "Intégration",
      "Capacité d’accueil"
    ],
    "rightKeywords": [
      "Accueil",
      "Régularisation",
      "Droits",
      "Solidarité"
    ],
    "positions": {
      "rn": 5,
      "reconquete": 2,
      "lr": 18,
      "renaissance": 45,
      "ps": 60,
      "lfi": 85,
      "pcf": 70,
      "eelv": 82,
      "upr": 10,
      "patriotes": 5,
      "dlf": 12,
      "rep_souveraine": 18,
      "nouvelle_energie": 15,
      "generations": 75
    },
    "ic": {
      "rn": 4,
      "reconquete": 4,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 3,
      "eelv": 4,
      "upr": 4,
      "patriotes": 4,
      "dlf": 4,
      "rep_souveraine": 3,
      "nouvelle_energie": 4,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN 2024",
        "date": "2024-06",
        "link": "https://rassemblementnational.fr/documents/202406-programme.pdf",
        "comment": "Immigration zéro nette; fin droit sol; OQTF systématiques"
      },
      "reconquete": {
        "ic": "IC4",
        "source": "Programme présidentiel Zemmour 2022",
        "date": "2022-01",
        "link": "https://www.reconquete.fr/programme",
        "comment": "Immigration proche zéro; grand remplacement; remigration"
      },
      "lr": {
        "ic": "IC4",
        "source": "Programme LR 2022",
        "date": "2022-01",
        "link": "https://www.republicains.fr",
        "comment": "Maîtrise stricte; chiffres bas; expulsions renforcées"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Programme Ensemble 2024",
        "date": "2024-06",
        "link": "https://parti-renaissance.fr",
        "comment": "Maîtrise + accueil légal; équilibre affiché"
      },
      "ps": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Accueil digne; régularisation; droit asile renforcé"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Régularisation; droit sol étendu; accueil ouvert"
      },
      "pcf": {
        "ic": "IC3",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "Accueil solidaire; régularisation; droits travailleurs migrants"
      },
      "eelv": {
        "ic": "IC4",
        "source": "Programme EELV 2022",
        "date": "2022-01",
        "link": "https://lesecologistes.eu",
        "comment": "Accueil ouvert; migration climatique reconnue; droits élargis"
      },
      "upr": {
        "ic": "IC4",
        "source": "MonVote2027 — positions UPR vérifiées",
        "date": "2021-10",
        "link": "https://monvote2027.fr/candidat/asselineau",
        "comment": "Maîtrise stricte; fin droit sol (référendum); OQTF 75%; suppression AME; Frexit = contrôle frontières"
      },
      "patriotes": {
        "ic": "IC4",
        "source": "Grandes orientations Les Patriotes",
        "date": "2024-01",
        "link": "https://www.candidatspresidentielles2027.fr/candidats/florian-philippot",
        "comment": "Immigration fortement réduite; OQTF systématiques; quitter Schengen; fin droit sol"
      },
      "dlf": {
        "ic": "IC4",
        "source": "Wikipedia DLF — immigration",
        "date": "2006-05",
        "link": "https://fr.wikipedia.org/wiki/Debout_la_France",
        "comment": "Réduction très forte immigration; fin droit sol; contrôle frontières; référendum"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "Site republique-souveraine.fr/nosidees",
        "date": "2025-10",
        "link": "https://www.republique-souveraine.fr/nosidees",
        "comment": "Contrôle frontières; respecter droits asile ONU; maîtrise immigration économique; référendum"
      },
      "nouvelle_energie": {
        "ic": "IC4",
        "source": "Programme NE immigration — unenouvelleenergie.fr",
        "date": "2025-08",
        "link": "https://www.unenouvelleenergie.fr/notre-programme/immigration/",
        "comment": "Titres séjour/8; fin droit sol automatique; CEDH bras de fer; AME supprimée; quotas qualifiés"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon 2017",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "Accueil ouvert; régularisation; migration climatique; droits élargis — IC2"
      }
    }
  },
  {
    "id": "europe",
    "icon": "🇫🇷",
    "name": "Europe",
    "question": "Quel niveau de souveraineté la France doit-elle conserver face à l'Union européenne ?",
    "left": "Souveraineté nationale renforcée",
    "right": "Intégration européenne renforcée",
    "measure": "Le curseur mesure l'importance accordée à la souveraineté nationale par rapport à l'intégration européenne.",
    "leftSoft": "Vous privilégiez plutôt la capacité de la France à reprendre la main sur ses lois, son budget, son énergie, son industrie et ses frontières économiques.",
    "leftStrong": "Vous privilégiez fortement un retour de compétences stratégiques au niveau national.",
    "center": "Vous recherchez un équilibre entre souveraineté nationale et coopération européenne.",
    "rightSoft": "Vous privilégiez plutôt les règles communes, le marché européen et les décisions partagées à l’échelle de l’Union.",
    "rightStrong": "Vous privilégiez fortement l’intégration européenne et la construction d’une puissance commune.",
    "leftKeywords": [
      "Lois",
      "Budget",
      "Frontières",
      "Souveraineté"
    ],
    "rightKeywords": [
      "Union européenne",
      "Règles communes",
      "Marché",
      "Décisions partagées"
    ],
    "positions": {
      "rn": 20,
      "reconquete": 15,
      "lr": 55,
      "renaissance": 82,
      "ps": 75,
      "lfi": 28,
      "pcf": 35,
      "eelv": 85,
      "upr": 2,
      "patriotes": 3,
      "dlf": 30,
      "rep_souveraine": 3,
      "nouvelle_energie": 50,
      "generations": 80
    },
    "ic": {
      "rn": 4,
      "reconquete": 3,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 3,
      "eelv": 4,
      "upr": 4,
      "patriotes": 4,
      "dlf": 3,
      "rep_souveraine": 3,
      "nouvelle_energie": 3,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Vote AN juin 2025 (Le Monde)",
        "date": "2025-06",
        "link": "https://www.lemonde.fr/politique/article/2025/06/20/sur-l-energie-le-rn-aligne-les-victoires",
        "comment": "Eurosceptique fort mais reste dans UE; contre fédéralisme"
      },
      "reconquete": {
        "ic": "IC3",
        "source": "Programme présidentiel Zemmour 2022",
        "date": "2022-01",
        "link": "https://www.reconquete.fr/programme",
        "comment": "Souverainiste; contre UE fédérale; primauté droit national"
      },
      "lr": {
        "ic": "IC4",
        "source": "Vote européens 2024",
        "date": "2024-06",
        "link": "https://www.atelier-europe.eu/blog/2024/06/demandez-le-programme.html",
        "comment": "Pro-européen modéré; Europe des nations; contre fédéralisme"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Vote européens 2024",
        "date": "2024-06",
        "link": "https://www.atelier-europe.eu/blog/2024/06/demandez-le-programme.html",
        "comment": "Pro-européen fort; approfondissement UE; défense commune"
      },
      "ps": {
        "ic": "IC4",
        "source": "Européennes 2024 — liste Glucksmann PS",
        "date": "2024-06",
        "link": "https://www.atelier-europe.eu/blog/2024/06/demandez-le-programme.html",
        "comment": "Pro-européen; Europe sociale; approfondir intégration"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Europe sociale; désobéissance traités; souveraineté + UE alternative"
      },
      "pcf": {
        "ic": "IC3",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "Europe sociale; contre UE libérale; souveraineté + coopération"
      },
      "eelv": {
        "ic": "IC4",
        "source": "Européennes 2024",
        "date": "2024-06",
        "link": "https://lesecologistes.eu",
        "comment": "Fédéralisme européen; intégration maximale; Europe verte"
      },
      "upr": {
        "ic": "IC4",
        "source": "Charte fondatrice UPR 2007 + programme 2022",
        "date": "2022-01",
        "link": "https://upr.fr/actualites/programme-presidentiel-2022",
        "comment": "Frexit Article 50; sortie €+OTAN; souveraineté absolue; plus radical que RN sur Europe"
      },
      "patriotes": {
        "ic": "IC4",
        "source": "Programme européennes 2024 — 'L'Europe ça suffit!'",
        "date": "2024-05",
        "link": "https://www.dna.fr/elections/2024/05/29/tout-savoir-sur-la-liste-les-patriotes",
        "comment": "Frexit radical; sortie UE+€+OTAN+CEDH+OMS; plus radical qu'UPR sur sortie CEDH"
      },
      "dlf": {
        "ic": "IC3",
        "source": "Wikipedia DLF — position européenne",
        "date": "2006-05",
        "link": "https://fr.wikipedia.org/wiki/Debout_la_France",
        "comment": "Europe des nations et projets; eurosceptique modéré; contre fédéralisme; sortie OTAN"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "Wikipedia RS + YouTube Kuzmanovic",
        "date": "2022-01",
        "link": "https://fr.wikipedia.org/wiki/R%C3%A9publique_souveraine",
        "comment": "Abroger traité Lisbonne; Europe coopération États souverains; quitter OTAN; sortir €"
      },
      "nouvelle_energie": {
        "ic": "IC3",
        "source": "Wikipedia NE + programme",
        "date": "2025-11",
        "link": "https://fr.wikipedia.org/wiki/Nouvelle_%C3%89nergie",
        "comment": "Souverainisme modéré; Europe technocratique critiquée; provinces décentralisation; ni Frexit ni fédéralisme"
      },
      "generations": {
        "ic": "IC2",
        "source": "Européennes 2019 Génération·s",
        "date": "2019-05",
        "link": "https://generationsmouvement.fr",
        "comment": "Pro-européen fort; Europe sociale et écologique; fédéralisme partiel — IC2"
      }
    }
  },
  {
    "id": "education",
    "icon": "📚",
    "name": "Éducation",
    "question": "Quelle mission prioritaire donner à l'école ?",
    "left": "Préparer davantage aux métiers et compétences dont le pays a besoin",
    "right": "Renforcer la transmission des savoirs académiques et les parcours d’études",
    "measure": "Le curseur mesure l'importance accordée à la préparation aux métiers et compétences utiles par rapport à la priorité donnée aux savoirs académiques et aux parcours d'études.",
    "leftSoft": "Vous privilégiez plutôt une école qui prépare davantage aux métiers nécessaires au pays, à l’alternance, aux savoir-faire et au savoir-être.",
    "leftStrong": "Vous privilégiez fortement l’orientation vers les métiers utiles, les compétences concrètes et les filières professionnelles.",
    "center": "Vous recherchez un équilibre entre compétences professionnelles, savoirs fondamentaux et ascension par les diplômes.",
    "rightSoft": "Vous privilégiez plutôt la transmission académique, l’exigence scolaire et les parcours généraux ou supérieurs.",
    "rightStrong": "Vous privilégiez fortement les savoirs fondamentaux, l’excellence académique et l’ascension par les diplômes.",
    "leftKeywords": [
      "Métiers",
      "Alternance",
      "Savoir-faire",
      "Compétences"
    ],
    "rightKeywords": [
      "Savoirs",
      "Diplômes",
      "Exigence",
      "Parcours général"
    ],
    "positions": {
      "rn": 25,
      "reconquete": 30,
      "lr": 30,
      "renaissance": 55,
      "ps": 55,
      "lfi": 60,
      "pcf": 40,
      "eelv": 65,
      "upr": 30,
      "patriotes": 20,
      "dlf": 28,
      "rep_souveraine": 30,
      "nouvelle_energie": 45,
      "generations": 60
    },
    "ic": {
      "rn": 4,
      "reconquete": 3,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 3,
      "eelv": 3,
      "upr": 3,
      "patriotes": 3,
      "dlf": 3,
      "rep_souveraine": 3,
      "nouvelle_energie": 3,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN 2024",
        "date": "2024-06",
        "link": "https://rassemblementnational.fr/documents/202406-programme.pdf",
        "comment": "Filières professionnelles valorisées; apprentissage"
      },
      "reconquete": {
        "ic": "IC3",
        "source": "Programme présidentiel Zemmour 2022",
        "date": "2022-01",
        "link": "https://www.reconquete.fr/programme",
        "comment": "Filières pro valorisées; autorité à l'école; mérite"
      },
      "lr": {
        "ic": "IC4",
        "source": "Programme LR 2022",
        "date": "2022-01",
        "link": "https://www.republicains.fr",
        "comment": "Filières pro; apprentissage; mérite académique"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Programme Ensemble 2024",
        "date": "2024-06",
        "link": "https://parti-renaissance.fr",
        "comment": "École de la République; apprentissage + académique; équilibre"
      },
      "ps": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Éducation nationale renforcée; alternance reconnue"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Service public éducation; gratuité; lycées pro améliorés"
      },
      "pcf": {
        "ic": "IC3",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "École publique forte; lycées pro revalorisés; égalité"
      },
      "eelv": {
        "ic": "IC3",
        "source": "Programme EELV 2022",
        "date": "2022-01",
        "link": "https://lesecologistes.eu",
        "comment": "Éducation critique; sciences; parcours divers"
      },
      "upr": {
        "ic": "IC3",
        "source": "Programme présidentiel UPR 2022 — section 'Reconstruire l'école' (upr.fr)",
        "date": "2022-01",
        "link": "https://upr.fr/actualites/programme-presidentiel-2022",
        "comment": "Section dédiée : savoirs fondamentaux 80% primaire; filières techniques/pro revalorées; stages artisanat dès 4e; formation continue chambres métiers; référendum possible"
      },
      "patriotes": {
        "ic": "IC3",
        "source": "Grandes orientations Les Patriotes",
        "date": "2024-01",
        "link": "https://www.candidatspresidentielles2027.fr/candidats/florian-philippot",
        "comment": "École recentrée savoirs fondamentaux; autorité professeurs; culture commune; peu de détail alternance"
      },
      "dlf": {
        "ic": "IC3",
        "source": "Programme DLF 2017 (linfo.re PDF)",
        "date": "2017-01",
        "link": "https://www.linfo.re/programme_candidats/aignant.pdf",
        "comment": "Réforme Éducation nationale référendum; filières pro; mérite; autonomie établissements"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "YouTube La Grâce Matinale — Kuzmanovic fév 2022 (horodaté 20:05–22:30)",
        "date": "2022-02",
        "link": "https://www.youtube.com/watch?v=OHkvoCrtuOM",
        "comment": "Revalorisation enseignants; suppression réforme Jospin (écoles normales); uniforme; référendum Éducation; débat national avec professionnels — horodaté 20:05"
      },
      "nouvelle_energie": {
        "ic": "IC3",
        "source": "Programme NE éducation + Institut Diderot",
        "date": "2023-12",
        "link": "https://www.institutdiderot.fr/wp-content/uploads/2023/12/David-Lisnard-La-droite-en-france-Page.pdf",
        "comment": "Révolution école; décentralisation; liberté pédagogique; mixte académique/professionnel"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon 2017",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "Éducation nationale; salaire apprentis; égalité territoriale — IC2"
      }
    }
  },
  {
    "id": "ecologie",
    "icon": "🌍",
    "name": "Écologie",
    "question": "Quelle écologie faut-il privilégier ?",
    "left": "Écologie productive et technologique",
    "right": "Écologie de transformation des usages",
    "measure": "Le curseur mesure l'importance accordée aux solutions technologiques et productives par rapport à la transformation des comportements et des usages.",
    "leftSoft": "Vous privilégiez plutôt l’innovation, l’industrie propre, la réparation, la durabilité et la production locale.",
    "leftStrong": "Vous privilégiez fortement une écologie productive fondée sur l’innovation, la technologie, le nucléaire et la production locale.",
    "center": "Vous recherchez un équilibre entre innovation productive et évolution des comportements.",
    "rightSoft": "Vous privilégiez plutôt la sobriété, les normes, les interdictions ciblées, les taxes écologiques et les changements rapides d’usages.",
    "rightStrong": "Vous privilégiez fortement une transformation rapide des usages, de la consommation et des comportements.",
    "leftKeywords": [
      "Innovation",
      "Industrie propre",
      "Réparation",
      "Production locale"
    ],
    "rightKeywords": [
      "Sobriété",
      "Normes",
      "Taxes",
      "Comportements"
    ],
    "positions": {
      "rn": 8,
      "reconquete": 10,
      "lr": 25,
      "renaissance": 60,
      "ps": 70,
      "lfi": 88,
      "pcf": 75,
      "eelv": 95,
      "upr": 22,
      "patriotes": 15,
      "dlf": 25,
      "rep_souveraine": 25,
      "nouvelle_energie": 42,
      "generations": 88
    },
    "ic": {
      "rn": 4,
      "reconquete": 3,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 3,
      "eelv": 4,
      "upr": 3,
      "patriotes": 3,
      "dlf": 3,
      "rep_souveraine": 3,
      "nouvelle_energie": 3,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN 2024",
        "date": "2024-06",
        "link": "https://rassemblementnational.fr/documents/202406-programme.pdf",
        "comment": "Écologie productive; refus ZFE; moratoire éolien"
      },
      "reconquete": {
        "ic": "IC3",
        "source": "Programme présidentiel Zemmour 2022",
        "date": "2022-01",
        "link": "https://www.reconquete.fr/programme",
        "comment": "Nucléaire base; sceptique ENR; croissance avant écologie"
      },
      "lr": {
        "ic": "IC4",
        "source": "Programme LR 2022",
        "date": "2022-01",
        "link": "https://www.republicains.fr",
        "comment": "Écologie raisonnable; souveraineté énergétique; refus décroissance"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Programme Ensemble 2024",
        "date": "2024-06",
        "link": "https://parti-renaissance.fr",
        "comment": "Transition écologique pilotée; ENR + nucléaire; objectifs 2050"
      },
      "ps": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Transition ambitieuse; planification écologique; 100% ENR 2050"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "Planification écologique; 100% ENR; sobriété"
      },
      "pcf": {
        "ic": "IC3",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "Planification écologique; nationalisations vertes; sobriété"
      },
      "eelv": {
        "ic": "IC4",
        "source": "Programme EELV 2022",
        "date": "2022-01",
        "link": "https://lesecologistes.eu",
        "comment": "Transformation radicale; sobriété; 100% ENR; cœur identitaire"
      },
      "upr": {
        "ic": "IC3",
        "source": "Programme UPR 2022 + Wikipedia",
        "date": "2022-01",
        "link": "https://fr.wikipedia.org/wiki/Union_populaire_r%C3%A9publicaine_(2007)",
        "comment": "Interdiction pesticides dangereux sans perte revenus; ENR secondaire; écologie non centrale"
      },
      "patriotes": {
        "ic": "IC3",
        "source": "Grandes orientations Les Patriotes",
        "date": "2024-01",
        "link": "https://www.candidatspresidentielles2027.fr/candidats/florian-philippot",
        "comment": "Écologie circuits courts; protectionnisme vert; biodiversité; contre éoliennes; nucléaire base"
      },
      "dlf": {
        "ic": "IC3",
        "source": "Wikipedia DLF — environnement + YouTube 2026",
        "date": "2026-03",
        "link": "https://www.youtube.com/watch?v=IzkpvEQBxl4",
        "comment": "Énergie indépendance; nucléaire; bonus-malus comportements pollueurs; droits animaux; chasse maintenue"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "Wikipedia RS — transition écologique",
        "date": "2022-01",
        "link": "https://fr.wikipedia.org/wiki/R%C3%A9publique_souveraine",
        "comment": "Transition écologique planifiée par État; nucléaire + ENR; écologie productive souveraine"
      },
      "nouvelle_energie": {
        "ic": "IC3",
        "source": "Institut Diderot — économie écologique marché",
        "date": "2023-12",
        "link": "https://www.institutdiderot.fr/wp-content/uploads/2023/12/David-Lisnard-La-droite-en-france-Page.pdf",
        "comment": "Économie écologique de marché; croissance sauvera planète; innovation techno; pas écologie transformatrice"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon 2017 — 100% ENR",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "Transition radicale; 100% ENR; sobriété; proches EELV — IC2 peu de sources récentes"
      }
    }
  },
  {
    "id": "controle_elus",
    "icon": "🗳️",
    "name": "Contrôle des élus",
    "question": "Comment les citoyens doivent-ils contrôler les engagements politiques ?",
    "left": "Démocratie représentative classique",
    "right": "Démocratie directe et suivi public des engagements",
    "measure": "Le curseur mesure l'importance accordée à la démocratie représentative classique par rapport aux mécanismes de contrôle citoyen direct.",
    "leftSoft": "Vous privilégiez plutôt le fonctionnement représentatif classique : les citoyens choisissent leurs élus puis jugent leur bilan à l’élection suivante.",
    "leftStrong": "Vous privilégiez fortement le mandat représentatif classique et le jugement global par les élections.",
    "center": "Vous recherchez un équilibre entre représentation, responsabilité électorale et participation citoyenne.",
    "rightSoft": "Vous privilégiez plutôt le suivi public des engagements, davantage de référendums, le RIC ou d’autres outils de contrôle direct.",
    "rightStrong": "Vous privilégiez fortement la démocratie directe, le contrôle citoyen continu et la vérification publique des promesses.",
    "leftKeywords": [
      "Élection",
      "Mandat",
      "Bilan",
      "Institutions"
    ],
    "rightKeywords": [
      "RIC",
      "Référendum",
      "Suivi",
      "Contrôle citoyen"
    ],
    "positions": {
      "rn": 35,
      "reconquete": 70,
      "lr": 65,
      "renaissance": 72,
      "ps": 50,
      "lfi": 10,
      "pcf": 20,
      "eelv": 30,
      "upr": 5,
      "patriotes": 5,
      "dlf": 15,
      "rep_souveraine": 5,
      "nouvelle_energie": 55,
      "generations": 25
    },
    "ic": {
      "rn": 4,
      "reconquete": 2,
      "lr": 3,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 3,
      "eelv": 3,
      "upr": 4,
      "patriotes": 4,
      "dlf": 3,
      "rep_souveraine": 4,
      "nouvelle_energie": 3,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN 2024",
        "date": "2024-06",
        "link": "https://rassemblementnational.fr/documents/202406-programme.pdf",
        "comment": "RIP mais pas RIC constitutionnel; démocratie représentative dominante"
      },
      "reconquete": {
        "ic": "IC2",
        "source": "Zemmour interviews 2022",
        "date": "2022-03",
        "link": "https://www.reconquete.fr",
        "comment": "Peu de positions RIC; démocratie représentative; régime présidentiel fort"
      },
      "lr": {
        "ic": "IC3",
        "source": "Programme LR 2022",
        "date": "2022-01",
        "link": "https://www.republicains.fr",
        "comment": "Démocratie représentative; réticent RIC; Sénat fort"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Programme Ensemble 2024",
        "date": "2024-06",
        "link": "https://parti-renaissance.fr",
        "comment": "Démocratie représentative; refus RIC pur; consultation"
      },
      "ps": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "RIC partiel; démocratie représentative + participative"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024 + position RIC",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "RIC constitutionnel; référendums; 6e République"
      },
      "pcf": {
        "ic": "IC3",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "Démocratie participative; RIC; 6e République"
      },
      "eelv": {
        "ic": "IC3",
        "source": "Programme EELV 2022",
        "date": "2022-01",
        "link": "https://lesecologistes.eu",
        "comment": "RIC; démocratie participative; mouvements citoyens"
      },
      "upr": {
        "ic": "IC4",
        "source": "Programme UPR 2022 — RIC constitutionnel",
        "date": "2022-01",
        "link": "https://upr.fr/actualites/programme-presidentiel-2022",
        "comment": "RIC inscrit Constitution; seuil 2% électeurs; 4 matières (législatif/abrogatoire/constitutionnel/révocatoire)"
      },
      "patriotes": {
        "ic": "IC4",
        "source": "Grandes orientations Les Patriotes",
        "date": "2024-01",
        "link": "https://www.candidatspresidentielles2027.fr/candidats/florian-philippot",
        "comment": "RIC sur tout sujet inscrit Constitution; suppression Congrès; révision constitutionnelle par référendum"
      },
      "dlf": {
        "ic": "IC3",
        "source": "Wikipedia DLF — institutions",
        "date": "2006-05",
        "link": "https://fr.wikipedia.org/wiki/Debout_la_France",
        "comment": "Vote obligatoire; proportionnelle; vote blanc reconnu; démocratie participative; inéligibilité corruption"
      },
      "rep_souveraine": {
        "ic": "IC4",
        "source": "Wikipedia RS — RIC central",
        "date": "2022-01",
        "link": "https://fr.wikipedia.org/wiki/R%C3%A9publique_souveraine",
        "comment": "RIC inscrit Constitution; référendum pour valider programme; démocratie directe centrale"
      },
      "nouvelle_energie": {
        "ic": "IC3",
        "source": "Programme NE institutions",
        "date": "2025-11",
        "link": "https://www.unenouvelleenergie.fr/notre-programme/",
        "comment": "Décentralisation radicale; renouveau civique; peu de RIC; démocratie représentative + participative"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon 2017",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "RIC; démocratie participative; 6e République — IC2"
      }
    }
  },
  {
    "id": "dette",
    "icon": "🏛️",
    "name": "Argent public et dette",
    "question": "Comment gérer la dépense publique et la dette ?",
    "left": "Réduction du périmètre de l’État et audit contraignant",
    "right": "Maintien d’un État social fort",
    "measure": "Le curseur mesure l'importance accordée à la réduction du périmètre de l'État par rapport au maintien d'un niveau élevé de services publics et de redistribution.",
    "leftSoft": "Vous privilégiez plutôt la suppression des doublons, la réduction des dépenses peu utiles, la réallocation vers les priorités et la baisse de la dette.",
    "leftStrong": "Vous privilégiez fortement l’audit contraignant de l’argent public, la réduction des dépenses et la diminution de la dette.",
    "center": "Vous recherchez un équilibre entre maîtrise budgétaire, services publics et protection sociale.",
    "rightSoft": "Vous privilégiez plutôt le maintien ou le renforcement de l’État social, même avec un niveau élevé de dépense publique.",
    "rightStrong": "Vous privilégiez fortement les services publics, la redistribution et la protection sociale, même si la dépense reste élevée.",
    "leftKeywords": [
      "Audit",
      "Dette",
      "Doublons",
      "Réallocation"
    ],
    "rightKeywords": [
      "Services publics",
      "Redistribution",
      "État social",
      "Protection"
    ],
    "positions": {
      "rn": 30,
      "reconquete": 25,
      "lr": 20,
      "renaissance": 55,
      "ps": 70,
      "lfi": 85,
      "pcf": 90,
      "eelv": 75,
      "upr": 30,
      "patriotes": 25,
      "dlf": 22,
      "rep_souveraine": 20,
      "nouvelle_energie": 15,
      "generations": 80
    },
    "ic": {
      "rn": 4,
      "reconquete": 3,
      "lr": 4,
      "renaissance": 4,
      "ps": 4,
      "lfi": 4,
      "pcf": 3,
      "eelv": 3,
      "upr": 3,
      "patriotes": 3,
      "dlf": 3,
      "rep_souveraine": 3,
      "nouvelle_energie": 4,
      "generations": 2
    },
    "sources": {
      "rn": {
        "ic": "IC4",
        "source": "Programme RN 2024",
        "date": "2024-06",
        "link": "https://rassemblementnational.fr/documents/202406-programme.pdf",
        "comment": "Baisse dette affichée; maintien allocations; TVA 0 aliments"
      },
      "reconquete": {
        "ic": "IC3",
        "source": "Programme présidentiel Zemmour 2022",
        "date": "2022-01",
        "link": "https://www.reconquete.fr/programme",
        "comment": "Baisse dette; réduction dépenses publiques; État régalien fort"
      },
      "lr": {
        "ic": "IC4",
        "source": "Programme LR 2022",
        "date": "2022-01",
        "link": "https://www.republicains.fr",
        "comment": "Baisse dette priorité; réduction dépenses; réforme retraites"
      },
      "renaissance": {
        "ic": "IC4",
        "source": "Programme Ensemble 2024",
        "date": "2024-06",
        "link": "https://parti-renaissance.fr",
        "comment": "Sérieux budgétaire + maintien services publics; équilibre"
      },
      "ps": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "État social fort; services publics; retraites 60 ans"
      },
      "lfi": {
        "ic": "IC4",
        "source": "Programme NFP 2024",
        "date": "2024-06",
        "link": "https://lafranceinsoumise.fr/wp-content/uploads/2024/06/Programme-nouveaufrontpopulaire.pdf",
        "comment": "État social maximal; services publics; dette acceptée"
      },
      "pcf": {
        "ic": "IC3",
        "source": "Programme PCF 2022",
        "date": "2022-01",
        "link": "https://www.pcf.fr",
        "comment": "État social maximal; dette refusée comme frein; services publics"
      },
      "eelv": {
        "ic": "IC3",
        "source": "Programme EELV 2022",
        "date": "2022-01",
        "link": "https://lesecologistes.eu",
        "comment": "État social + transition; investissements publics; accepte dette verte"
      },
      "upr": {
        "ic": "IC3",
        "source": "Programme UPR 2022",
        "date": "2022-01",
        "link": "https://upr.fr/actualites/programme-presidentiel-2022",
        "comment": "Maîtrise dette via Frexit; État social CNR maintenu; Sécu 100% remboursée; investissements publics"
      },
      "patriotes": {
        "ic": "IC3",
        "source": "Grandes orientations + Wikipedia",
        "date": "2024-01",
        "link": "https://fr.wikipedia.org/wiki/Les_Patriotes_(parti_politique)",
        "comment": "Frexit = 15Md€/an économisés; État social maintenu; augmentation SMIC 25%/5ans; retraites 60 ans"
      },
      "dlf": {
        "ic": "IC3",
        "source": "Wikipedia DLF — finances publiques",
        "date": "2006-05",
        "link": "https://fr.wikipedia.org/wiki/Debout_la_France",
        "comment": "Banque de France monétise dette; emprunts taux zéro; réduction niches fiscales; dette maîtrisée"
      },
      "rep_souveraine": {
        "ic": "IC3",
        "source": "YouTube Kuzmanovic + Wikipedia",
        "date": "2022-01",
        "link": "https://www.youtube.com/watch?v=4IOkNIhQ5oI",
        "comment": "État planificateur; maîtrise budgétaire; souveraineté monétaire; services publics CNR"
      },
      "nouvelle_energie": {
        "ic": "IC4",
        "source": "Institut Diderot + programme NE",
        "date": "2023-12",
        "link": "https://www.institutdiderot.fr/wp-content/uploads/2023/12/David-Lisnard-La-droite-en-france-Page.pdf",
        "comment": "Réduction dépenses publiques; État efficace régalien; retraite capitalisation; baisse dette prioritaire"
      },
      "generations": {
        "ic": "IC2",
        "source": "Programme Hamon 2017 — revenu universel",
        "date": "2017-01",
        "link": "https://generationsmouvement.fr",
        "comment": "Revenu universel; État social fort; dette acceptable pour transformation — IC2"
      }
    }
  }
];
