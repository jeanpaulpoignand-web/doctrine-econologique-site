export const parties = [
  { id: 'rn', name: 'Rassemblement National', short: 'RN', color: '#1d4ed8' },
  { id: 'reconquete', name: 'Reconquête', short: 'Reconquête', color: '#7f1d1d' },
  { id: 'dlf', name: 'Debout la France', short: 'DLF', color: '#2563eb' },
  { id: 'upr', name: 'UPR', short: 'UPR', color: '#0f766e' },
  { id: 'patriotes', name: 'Les Patriotes', short: 'Patriotes', color: '#0284c7' },
  { id: 'rep_souveraine', name: 'République Souveraine', short: 'RS', color: '#9333ea' },
  { id: 'nouvelle_energie', name: 'Nouvelle Énergie — David Lisnard', short: 'Nouvelle Énergie', color: '#f59e0b' },
  { id: 'lr', name: 'Les Républicains', short: 'LR', color: '#0066cc' },
  { id: 'renaissance', name: 'Renaissance / Ensemble', short: 'Renaissance', color: '#fb923c' },
  { id: 'modem', name: 'MoDem', short: 'MoDem', color: '#eab308' },
  { id: 'horizons', name: 'Horizons', short: 'Horizons', color: '#38bdf8' },
  { id: 'ps', name: 'Parti Socialiste', short: 'PS', color: '#e11d48' },
  { id: 'lfi', name: 'La France Insoumise', short: 'LFI', color: '#dc2626' },
  { id: 'eelv', name: 'Les Écologistes / EELV', short: 'EELV', color: '#16a34a' },
  { id: 'pcf', name: 'Parti Communiste Français', short: 'PCF', color: '#b91c1c' }
];

export const axes = [
  {
    id: 'energie', icon: '⚡', name: 'Énergie',
    question: 'La France doit-elle reprendre le contrôle complet de son électricité pour garantir une énergie abondante, stable et bon marché ?',
    left: 'Marché européen / concurrence', right: 'Souveraineté publique / prix national maîtrisé',
    explanation: 'Le curseur mesure le niveau de reprise en main publique, nationale et productive de l’électricité.',
    positions: { rn:78, reconquete:82, dlf:90, upr:95, patriotes:94, rep_souveraine:84, nouvelle_energie:72, lr:70, renaissance:55, modem:54, horizons:58, ps:52, lfi:61, eelv:24, pcf:74 },
    confidence: { upr:.9, dlf:.86, patriotes:.82, rn:.78, reconquete:.75, lr:.7, renaissance:.7, eelv:.82, pcf:.66, nouvelle_energie:.55 }
  },
  {
    id: 'sante', icon: '🏥', name: 'Santé / déserts médicaux',
    question: 'Face aux déserts médicaux, quel principe doit primer ?',
    left: 'Priorité nationale de santé publique', right: 'Libre circulation totale',
    explanation: 'Le curseur mesure la priorité donnée au maintien des soignants formés en France et à la couverture médicale du territoire.',
    positions: { rn:32, reconquete:42, dlf:27, upr:38, patriotes:36, rep_souveraine:34, nouvelle_energie:38, lr:45, renaissance:58, modem:55, horizons:52, ps:37, lfi:30, eelv:40, pcf:28 },
    confidence: { rn:.48, reconquete:.35, dlf:.45, upr:.32, patriotes:.32, rep_souveraine:.3, nouvelle_energie:.38, lr:.45, renaissance:.65, modem:.45, horizons:.45, ps:.55, lfi:.55, eelv:.45, pcf:.55 },
    democraticVoidHint: true
  },
  {
    id: 'agriculture', icon: '🌾', name: 'Agriculture locale',
    question: 'Pour l’alimentation, quel cap faut-il privilégier ?',
    left: 'Production locale souveraine', right: 'Libre-échange agricole mondial',
    explanation: 'Le curseur oppose une logique de souveraineté alimentaire locale à une dépendance aux importations longues distances.',
    positions: { rn:18, reconquete:22, dlf:14, upr:16, patriotes:14, rep_souveraine:24, nouvelle_energie:32, lr:39, renaissance:55, modem:52, horizons:50, ps:38, lfi:26, eelv:30, pcf:24 },
    confidence: { rn:.74, dlf:.7, upr:.62, patriotes:.62, reconquete:.58, lfi:.63, eelv:.62, pcf:.55, renaissance:.55, lr:.55, nouvelle_energie:.45 }
  },
  {
    id: 'emploi_industrie', icon: '🏭', name: 'Emploi / industrie',
    question: 'Faut-il reconstruire des emplois productifs en France plutôt que dépendre des importations et services précaires ?',
    left: 'Économie ouverte de services', right: 'Réindustrialisation / production nationale',
    explanation: 'Le curseur mesure la priorité donnée à la production, aux emplois industriels et aux filières stratégiques.',
    positions: { rn:76, reconquete:72, dlf:86, upr:88, patriotes:84, rep_souveraine:80, nouvelle_energie:66, lr:58, renaissance:48, modem:48, horizons:52, ps:62, lfi:72, eelv:50, pcf:82 },
    confidence: { dlf:.76, upr:.72, rn:.7, patriotes:.65, pcf:.65, lfi:.6, reconquete:.55, rep_souveraine:.5, nouvelle_energie:.5, renaissance:.6, lr:.55 }
  },
  {
    id: 'justice', icon: '⚖️', name: 'Justice',
    question: 'La priorité doit-elle être une justice indépendante, rapide et réellement appliquée ?',
    left: 'Système actuel peu contrôlé', right: 'Indépendance, moyens, exécution effective',
    explanation: 'Le sujet n’est pas seulement la sévérité : il porte sur l’indépendance et l’exécution des décisions.',
    positions: { rn:62, reconquete:60, dlf:66, upr:70, patriotes:68, rep_souveraine:66, nouvelle_energie:63, lr:58, renaissance:45, modem:48, horizons:50, ps:55, lfi:58, eelv:52, pcf:56 },
    confidence: { upr:.42, dlf:.42, patriotes:.38, rn:.5, reconquete:.42, lr:.5, renaissance:.45, ps:.4, lfi:.45, eelv:.35, pcf:.36, nouvelle_energie:.4 },
    democraticVoidHint: true
  },
  {
    id: 'evasion_fiscale', icon: '🧾', name: 'Évasion fiscale',
    question: 'Face à l’évasion fiscale et à l’optimisation abusive, quel niveau d’exigence faut-il appliquer ?',
    left: 'Contrôle réel et sanctions effectives', right: 'Priorité faible / discours général',
    explanation: 'Le curseur teste l’exigence de contrôle, de transparence et de résultats mesurables face aux discours généraux.',
    positions: { rn:38, reconquete:50, dlf:34, upr:36, patriotes:38, rep_souveraine:32, nouvelle_energie:52, lr:58, renaissance:62, modem:60, horizons:60, ps:28, lfi:14, eelv:22, pcf:16 },
    confidence: { lfi:.7, pcf:.65, eelv:.6, ps:.55, rn:.42, dlf:.38, upr:.34, patriotes:.32, rep_souveraine:.32, renaissance:.5, lr:.45, nouvelle_energie:.28 },
    democraticVoidHint: true
  },
  {
    id: 'souverainete_europe', icon: '🇫🇷', name: 'Europe / souveraineté',
    question: 'La France doit-elle reprendre davantage de souveraineté face aux règles européennes quand elles nuisent à ses intérêts vitaux ?',
    left: 'Cadre européen prioritaire', right: 'Souveraineté nationale prioritaire',
    explanation: 'Le curseur mesure le degré de primauté donné aux intérêts nationaux sur les contraintes européennes.',
    positions: { rn:78, reconquete:82, dlf:88, upr:98, patriotes:96, rep_souveraine:86, nouvelle_energie:55, lr:50, renaissance:24, modem:22, horizons:28, ps:36, lfi:58, eelv:28, pcf:62 },
    confidence: { upr:.94, patriotes:.88, dlf:.82, rn:.78, reconquete:.78, rep_souveraine:.6, lfi:.55, pcf:.5, renaissance:.75, modem:.65, horizons:.6, eelv:.65, lr:.55, nouvelle_energie:.42 }
  },
  {
    id: 'immigration', icon: '👥', name: 'Immigration / intégration',
    question: 'Pour l’immigration, quel principe doit primer dans la décision publique ?',
    left: 'Contrôle selon capacité nationale', right: 'Accueil large',
    explanation: 'Le curseur mesure la priorité donnée à la capacité réelle d’intégration, de logement, d’emploi et de services publics.',
    positions: { rn:10, reconquete:6, dlf:22, upr:32, patriotes:24, rep_souveraine:36, nouvelle_energie:38, lr:32, renaissance:52, modem:56, horizons:50, ps:66, lfi:78, eelv:78, pcf:70 },
    confidence: { rn:.85, reconquete:.85, lr:.65, dlf:.58, patriotes:.54, renaissance:.65, modem:.55, ps:.58, lfi:.65, eelv:.65, pcf:.5, nouvelle_energie:.45, upr:.42 }
  },
  {
    id: 'education', icon: '📚', name: 'Éducation',
    question: 'Pour l’école, quelle priorité faut-il remettre au centre ?',
    left: 'Fondamentaux, exigence, autorité', right: 'Approche actuelle large',
    explanation: 'Le curseur porte sur les savoirs de base, l’autorité pédagogique et la transmission culturelle.',
    positions: { rn:22, reconquete:14, dlf:18, upr:28, patriotes:22, rep_souveraine:30, nouvelle_energie:24, lr:24, renaissance:48, modem:48, horizons:42, ps:58, lfi:70, eelv:72, pcf:62 },
    confidence: { reconquete:.7, rn:.65, lr:.65, dlf:.58, nouvelle_energie:.55, renaissance:.55, ps:.5, lfi:.55, eelv:.55, pcf:.45, upr:.38 }
  },
  {
    id: 'ecologie_productive', icon: '🚗', name: 'Écologie productive / ZFE',
    question: 'L’écologie doit-elle viser d’abord les absurdités productives : importations lointaines, trajets contraints, ZFE pénalisant les travailleurs modestes ?',
    left: 'Écologie réglementaire locale', right: 'Écologie productive, sociale, souveraine',
    explanation: 'Le curseur mesure une écologie qui réduit les flux inutiles et protège les travailleurs modestes au lieu de les bloquer.',
    positions: { rn:62, reconquete:55, dlf:70, upr:72, patriotes:68, rep_souveraine:66, nouvelle_energie:58, lr:45, renaissance:32, modem:34, horizons:36, ps:42, lfi:56, eelv:28, pcf:58 },
    confidence: { rn:.42, reconquete:.28, dlf:.35, upr:.32, patriotes:.35, rep_souveraine:.28, nouvelle_energie:.28, lr:.32, renaissance:.48, modem:.38, horizons:.38, ps:.34, lfi:.38, eelv:.55, pcf:.32 },
    democraticVoidHint: true
  },
  {
    id: 'controle_elus', icon: '🗳️', name: 'Contrôle des élus',
    question: 'Après une élection, les citoyens doivent-ils pouvoir suivre publiquement l’application réelle des engagements ?',
    left: 'Mandat libre sans suivi détaillé', right: 'Suivi public régulier des engagements',
    explanation: 'C’est le cœur du bulletin dynamique : voter, voir le résultat, puis contrôler l’exécution.',
    positions: { rn:45, reconquete:42, dlf:58, upr:66, patriotes:62, rep_souveraine:60, nouvelle_energie:46, lr:36, renaissance:30, modem:32, horizons:32, ps:42, lfi:56, eelv:50, pcf:54 },
    confidence: { upr:.5, patriotes:.42, dlf:.4, rep_souveraine:.34, lfi:.35, eelv:.32, pcf:.32, rn:.28, reconquete:.25, lr:.25, renaissance:.35, modem:.28, horizons:.28, nouvelle_energie:.25 },
    democraticVoidHint: true
  },
  {
    id: 'argent_public', icon: '🏛️', name: 'Argent public / dette',
    question: 'Avant d’augmenter impôts ou dette, quelle priorité faut-il donner à la transparence budgétaire ?',
    left: 'Audit et réallocation d’abord', right: 'Hausse possible des recettes publiques',
    explanation: 'Le curseur mesure l’exigence de rendre visibles les gaspillages, doublons administratifs et coûts cachés avant tout prélèvement supplémentaire.',
    positions: { rn:34, reconquete:32, dlf:26, upr:24, patriotes:28, rep_souveraine:30, nouvelle_energie:18, lr:28, renaissance:46, modem:48, horizons:40, ps:64, lfi:72, eelv:70, pcf:68 },
    confidence: { nouvelle_energie:.7, lr:.62, dlf:.55, upr:.5, patriotes:.48, rn:.5, reconquete:.5, renaissance:.6, horizons:.52, modem:.5, ps:.45, lfi:.5, eelv:.45, pcf:.42 }
  }
];
