# Bulletin de vote du futur proche — V8

Prototype React/Vite du module `qcm-democratie-decisionnelle`.

## Contenu V8

- 12 axes V7.3 intégrés
- curseur premium avec jeton circulaire, halo et agrandissement tactile
- texte pédagogique fixe + texte dynamique
- mots-clés dynamiques gauche/droite
- partis masqués pendant le vote
- résultat Top 4 avec score de compatibilité et IC moyen
- mode futur conceptuel : votre vote / résultat à 20h / application réelle

## Déploiement

Le workflow GitHub existant installe ce ZIP lorsqu'il est nommé :

`qcm-democratie-decisionnelle-v6-5-github-ready.zip`

Ce nom est conservé uniquement pour compatibilité avec le workflow historique.
