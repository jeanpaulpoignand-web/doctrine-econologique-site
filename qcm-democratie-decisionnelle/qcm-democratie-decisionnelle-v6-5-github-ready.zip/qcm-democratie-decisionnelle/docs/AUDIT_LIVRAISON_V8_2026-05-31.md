# Audit livraison V8 — 2026-05-31

## Contrôles réalisés

- Build Vite exécuté avec succès.
- 12 axes présents.
- 15 partis présents, dont MoDem et Horizons séparés comme dans la maquette historique.
- Chaque axe dispose de : question, pôle gauche, pôle droit, texte fixe, texte dynamique gauche/centre/droite, mots-clés gauche/droite, positions partis, IC.
- Le scoring utilise : proximité = 100 - distance absolue utilisateur/parti.
- Le score final est la moyenne des proximités disponibles.
- Le résultat affiche un Top 4, le nombre d'axes utilisés et l'IC moyen.
- Le mode futur est explicitement présenté comme démonstration conceptuelle.

## Point de compatibilité GitHub

Le fichier ZIP peut être renommé `qcm-democratie-decisionnelle-v6-5-github-ready.zip` pour être reconnu par le workflow historique codé en dur.
