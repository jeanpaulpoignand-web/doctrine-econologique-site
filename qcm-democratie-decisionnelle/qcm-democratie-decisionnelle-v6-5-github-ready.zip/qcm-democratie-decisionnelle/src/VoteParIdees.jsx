import React, { useMemo, useState } from 'react';
import { axes, axisMood, computeMatching } from './data.js';

function ProgressBar({ value, color = '#38bdf8' }) {
  return <div className="mini-progress"><span style={{ width: `${Math.max(0, Math.min(100, value))}%`, background: color }} /></div>;
}

function DynamicSlider({ axis, value, onChange }) {
  const mood = axisMood(value, axis);
  const leftActive = value < 45;
  const rightActive = value > 55;
  const fillStyle = {
    '--value': `${value}%`,
    '--accent': mood.color,
    '--glow': `${Math.max(14, mood.intensity)}px`
  };
  return (
    <div className={`slider-block ${mood.side}`} style={fillStyle}>
      <div className="scale-row">
        <div className={leftActive ? 'pole active left' : 'pole'}>{axis.left}</div>
        <div className="value-chip">{value}/100</div>
        <div className={rightActive ? 'pole active right' : 'pole'}>{axis.right}</div>
      </div>
      <input
        aria-label={axis.name}
        className="vote-slider"
        type="range"
        min="0"
        max="100"
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
      />
      <div className="dynamic-text" style={{ color: mood.color }}>
        {mood.label}
      </div>
      <div className="keywords-row">
        <div className={leftActive ? 'keywords lit-blue' : 'keywords'}>
          {axis.leftKeywords.map(k => <span key={k}>{k}</span>)}
        </div>
        <div className={rightActive ? 'keywords lit-orange' : 'keywords'}>
          {axis.rightKeywords.map(k => <span key={k}>{k}</span>)}
        </div>
      </div>
    </div>
  );
}

function QuestionScreen({ answers, setAnswer, current, setCurrent, showFuture, setShowFuture }) {
  const axis = axes[current];
  const value = answers[axis.id] ?? 50;
  const answeredCount = Object.values(answers).filter(v => typeof v === 'number').length;
  return (
    <main className="page">
      <section className="panel question-panel">
        <div className="top-nav">
          <button className="ghost" onClick={() => setCurrent(-1)}>← Accueil</button>
          <span className="nav-pill">Question {current + 1} / {axes.length}</span>
        </div>
        <div className="heading-panel">
          <div>
            <div className="section-kicker">{axis.icon} {axis.name}</div>
            <h1>{axis.question}</h1>
            <p className="measure-text">{axis.measure}</p>
          </div>
          <div className="progress-wrap">
            <strong>{answeredCount}/{axes.length} idées positionnées</strong>
            <div className="progress"><span style={{ width: `${((current + 1) / axes.length) * 100}%` }} /></div>
          </div>
        </div>
        <DynamicSlider axis={axis} value={value} onChange={(newValue) => setAnswer(axis.id, newValue)} />
        <div className="future-toggle">
          <label>
            <input type="checkbox" checked={showFuture} onChange={event => setShowFuture(event.target.checked)} />
            <span>Bulletin de vote du futur proche</span>
          </label>
        </div>
        {showFuture && (
          <div className="tracking-panel single">
            <article className="track-card">
              <div className="track-title"><span>🗳️</span><div><strong>Votre vote</strong><small>Votre position sur cet axe.</small></div></div>
              <ProgressBar value={value} color="#ffffff" />
            </article>
            <article className="track-card is-partial">
              <div className="track-title"><span>📊</span><div><strong>Résultat à 20h</strong><small>Démonstration conceptuelle, non alimentée par des données réelles.</small></div></div>
              <ProgressBar value={Math.max(0, Math.min(100, Math.round(value * .82 + 8)))} color="#38bdf8" />
            </article>
            <article className="track-card is-alert">
              <div className="track-title"><span>✅</span><div><strong>Application réelle</strong><small>Maquette du suivi futur des engagements.</small></div></div>
              <ProgressBar value={Math.max(0, Math.min(100, Math.round(value * .38)))} color="#22c55e" />
            </article>
          </div>
        )}
        <div className="actions spaced">
          <button className="ghost" disabled={current === 0} onClick={() => setCurrent(current - 1)}>← Précédent</button>
          {current < axes.length - 1 ? (
            <button className="btn primary" onClick={() => setCurrent(current + 1)}>Question suivante →</button>
          ) : (
            <button className="btn primary" onClick={() => setCurrent(axes.length)}>Voir mes résultats →</button>
          )}
        </div>
      </section>
    </main>
  );
}

function Results({ answers, setCurrent }) {
  const matching = useMemo(() => computeMatching(answers), [answers]);
  const top = matching.slice(0, 4);
  const winner = top[0];
  const convergence = winner?.details?.filter(d => d.proximity >= 78).slice(0, 5) ?? [];
  const divergence = winner?.details?.filter(d => d.proximity <= 55).sort((a,b) => a.proximity - b.proximity).slice(0, 4) ?? [];
  return (
    <main className="page">
      <section className="panel">
        <div className="top-nav"><button className="ghost" onClick={() => setCurrent(axes.length - 1)}>← Revenir</button><span className="nav-pill">Résultat transparent</span></div>
        <div className="result-hero">
          <div>
            <div className="section-kicker">Diagnostic démocratique</div>
            <h1>Vos réponses sont les plus proches de ces partis.</h1>
            <p>La compatibilité n’est pas une adhésion. Elle indique une proximité moyenne sur les axes renseignés.</p>
          </div>
          {winner && <div className="winner" style={{ '--party': winner.color }}><span>Plus proche</span><strong>{winner.name}</strong><b>{winner.score}%</b><small>{winner.usedAxes}/{axes.length} axes · IC moyen {winner.avgIc}/4</small></div>}
        </div>
        <div className="party-list">
          {top.map((party, index) => (
            <div className="party-row" key={party.id}>
              <span className="rank">{index + 1}</span>
              <strong>{party.name}</strong>
              <ProgressBar value={party.score} color={party.color} />
              <b>{party.score}%</b>
            </div>
          ))}
        </div>
        <div className="diagnostic-grid two">
          <article className="diagnostic-card ok"><strong>{winner?.usedAxes ?? 0}</strong><span>axes utilisés</span></article>
          <article className="diagnostic-card partial"><strong>{winner?.avgIc ?? 0}</strong><span>IC moyen / 4</span></article>
        </div>
        <div className="tracking-panel">
          <article className="track-card"><h2>Convergences principales</h2>{convergence.length ? convergence.map(d => <p key={d.axis}>✓ {d.axis} — {Math.round(d.proximity)}%</p>) : <p className="soft">Aucune convergence très forte.</p>}</article>
          <article className="track-card is-partial"><h2>Divergences principales</h2>{divergence.length ? divergence.map(d => <p key={d.axis}>• {d.axis} — {Math.round(d.proximity)}%</p>) : <p className="soft">Aucune divergence majeure.</p>}</article>
        </div>
        <div className="method-box"><h2>Méthode</h2><p>Proximité axe par axe = 100 − distance entre votre position et celle du parti. Le score final est la moyenne des proximités disponibles. Les sources et indices IC0–IC4 doivent rester consultables dans la page de traçabilité.</p></div>
      </section>
    </main>
  );
}

export default function VoteParIdees() {
  const [current, setCurrent] = useState(-1);
  const [showFuture, setShowFuture] = useState(false);
  const [answers, setAnswers] = useState(() => Object.fromEntries(axes.map(axis => [axis.id, 50])));
  const setAnswer = (id, value) => setAnswers(prev => ({ ...prev, [id]: value }));
  if (current === axes.length) return <Results answers={answers} setCurrent={setCurrent} />;
  if (current >= 0) return <QuestionScreen answers={answers} setAnswer={setAnswer} current={current} setCurrent={setCurrent} showFuture={showFuture} setShowFuture={setShowFuture} />;
  return (
    <main className="page hero-page">
      <section className="hero-card">
        <div className="hero-kicker">Maquette prospective · Pilier XIII · V8</div>
        <h1>Bulletin de vote du futur proche</h1>
        <p className="hero-lead">Continuez à voter pour des partis politiques, oui… <strong>mais après avoir testé vos idées</strong> sur les sujets eux-mêmes, compris les écarts et suivi l’application réelle des engagements.</p>
        <div className="concept-banner"><strong>Ce n’est pas un QCM scolaire ni un comparateur partisan classique.</strong><span>Vos idées d’abord, les partis seulement à la fin, puis le suivi de l’application réelle.</span></div>
        <div className="hero-grid">
          <button className="choice-card" onClick={() => setCurrent(0)}><span className="choice-icon">🗳️</span><strong>Je vote par mes idées</strong><em>12 questions concrètes, des curseurs dynamiques, puis un diagnostic démocratique.</em></button>
          <button className="choice-card secondary" onClick={() => setCurrent(axes.length)}><span className="choice-icon">🧭</span><strong>Je veux voir un résultat exemple</strong><em>Comparez ensuite votre intuition avec le résultat calculé.</em></button>
        </div>
        <div className="promise-row"><span>12 axes V7.3</span><span>15 partis</span><span>Curseurs premium</span><span>Textes dynamiques</span><span>Sources traçables</span></div>
      </section>
    </main>
  );
}
