# Modifications V8.1 — Vote démocratie décisionnelle

Objectif : sortir l’interface du vocabulaire “QCM” et renforcer la logique de vote citoyen.

## Changements principaux

- Remplacement de la bannière “Ce n’est pas un QCM partisan.”
  par “Vous votez sur des idées, pas sur des étiquettes.”
- Écran d’entrée renforcé :
  - “Vote par idées”
  - “Commencer le vote par idées”
  - “12 axes” au lieu de “12 questions”
  - rappel que les partis restent masqués pendant le vote.
- Ajout du retour au site Doctrine dès l’écran d’entrée via la barre haute.
- Navigation des axes :
  - “Axe 1 / 12” au lieu de “Question 1 / 12”
  - “Axe suivant”
  - “Axe précédent”
  - “Voir mon résultat de vote”
- Résultats :
  - “Résultat du vote”
  - “Votre bulletin”
  - “Top 4 des proximités politiques”
- Bouton haut :
  - “Recommencer le vote”
- Métadonnées HTML :
  - titre : “Vote par idées — Bulletin de démocratie décisionnelle”
  - description : “Vote citoyen par idées...”

## Build

Build Vite exécuté avec succès.

Fichiers de production générés dans `dist/` :
- `dist/index.html`
- `dist/assets/index-CLKVQ-ie.css`
- `dist/assets/index-kgGAVo_r.js`

## Déploiement GitHub Pages

Pour publier cette version :
1. Remplacer le contenu du dossier `qcm-democratie-decisionnelle/` du dépôt par le contenu de ce dossier.
2. Conserver la structure :
   - `qcm-democratie-decisionnelle/index.html`
   - `qcm-democratie-decisionnelle/assets/...`
3. Commit conseillé :
   `Update democracy vote interface V8.1`
