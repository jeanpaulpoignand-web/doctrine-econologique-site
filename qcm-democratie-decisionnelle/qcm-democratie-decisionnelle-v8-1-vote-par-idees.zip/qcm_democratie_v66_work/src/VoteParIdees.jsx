import React, { useMemo, useState } from 'react';
import { axes, parties } from './data.js';

const START_ANSWERS = Object.fromEntries(axes.map(axis => [axis.id, 50]));
const IC_LABEL = { 0: 'IC0 — source insuffisante', 1: 'IC1 — faible', 2: 'IC2 — modéré', 3: 'IC3 — bon', 4: 'IC4 — fort' };

function clamp(value) { return Math.max(0, Math.min(100, Math.round(value))); }
function tone(value) {
  if (value < 40) return 'left';
  if (value > 60) return 'right';
  return 'center';
}
function strength(value) { return Math.min(1, Math.abs(value - 50) / 50); }
function dynamicText(axis, value) {
  if (value <= 20) return axis.leftStrong;
  if (value < 40) return axis.leftSoft;
  if (value <= 60) return axis.center;
  if (value < 80) return axis.rightSoft;
  return axis.rightStrong;
}
function simulatedCollective(axisId, personal) {
  const seed = axisId.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
  const offset = (seed % 19) - 9;
  return clamp(personal + offset);
}
function simulatedExecution(axisId, collective) {
  const seed = axisId.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
  return clamp(16 + (collective / 100) * 52 + (seed % 15));
}
function partyAxisPosition(axis, partyId) { return axis.positions?.[partyId]; }
function partyAxisIC(axis, partyId) { return axis.ic?.[partyId] ?? 0; }
function axisScore(answer, axis, partyId) {
  const position = partyAxisPosition(axis, partyId);
  const ic = partyAxisIC(axis, partyId);
  if (position === null || position === undefined || ic === 0) return { score: null, distance: null, documented: false, ic };
  const distance = Math.abs(answer - position);
  return { score: 100 - distance, distance, documented: true, ic, position };
}
function computeMatching(answers) {
  return parties.map(party => {
    const byAxis = axes.map(axis => ({ axis, answer: answers[axis.id] ?? 50, ...axisScore(answers[axis.id] ?? 50, axis, party.id) }));
    const usable = byAxis.filter(x => x.documented);
    const match = usable.length ? Math.round(usable.reduce((sum, x) => sum + x.score, 0) / usable.length) : 0;
    const avgIC = usable.length ? usable.reduce((sum, x) => sum + x.ic, 0) / usable.length : 0;
    return { ...party, match, avgIC, axesUsed: usable.length, byAxis };
  }).sort((a, b) => b.match - a.match || b.avgIC - a.avgIC);
}
function topConvergences(party, count = 4) {
  return party.byAxis.filter(x => x.documented).sort((a, b) => a.distance - b.distance).slice(0, count);
}
function topDivergences(party, count = 3) {
  return party.byAxis.filter(x => x.documented).sort((a, b) => b.distance - a.distance).slice(0, count);
}
function avgResultIC(top) {
  const list = top.flatMap(p => p.byAxis.filter(x => x.documented).map(x => x.ic));
  return list.length ? (list.reduce((a, b) => a + b, 0) / list.length).toFixed(1) : '0.0';
}

function ProgressBar({ value, color = 'var(--blue)', kind = '' }) {
  return <div className={`progress ${kind}`}><span style={{ width: `${clamp(value)}%`, background: color }} /></div>;
}
function TopNav({ onReset, currentScreen }) {
  return <nav className="top-nav">
    <a href="../" className="back-link">← Retour au site Doctrine</a>
    <span className="nav-pill">Bulletin de vote du futur proche · V8</span>
    {currentScreen !== 'intro' && <button className="ghost" onClick={onReset}>Recommencer le vote</button>}
  </nav>;
}
function Intro({ start }) {
  return <main className="page hero-page"><TopNav currentScreen="intro" /><section className="hero-card">
    <span className="hero-kicker">Pilier XIII · Vote par idées · V8.1</span>
    <h1>Bulletin de vote du futur proche</h1>
    <p className="hero-lead"><strong>Vos idées d’abord. Les partis seulement à la fin.</strong><br/>Positionnez-vous sur 12 axes avec des curseurs dynamiques, puis découvrez les proximités politiques, les convergences, les divergences et la robustesse documentaire.</p>
    <div className="concept-banner"><strong>Vous votez sur des idées, pas sur des étiquettes.</strong><span>Les partis restent masqués pendant le vote. Le moteur compare ensuite vos positions à une matrice sourcée V7.3 bis.</span></div>
    <div className="hero-grid">
      <button className="choice-card" onClick={start}><span className="choice-icon">🗳️</span><strong>Commencer le vote par idées</strong><em>12 axes · 3 à 5 minutes · partis masqués pendant le vote.</em></button>
      <a className="choice-card secondary" href="#methode"><span className="choice-icon">🔎</span><strong>Voir la méthode</strong><em>Manhattan, IC0–IC4, sources et traçabilité.</em></a>
    </div>
    <div className="promise-row"><span>12 axes de vote</span><span>14 partis masqués</span><span>Top 4 final</span><span>IC0–IC4</span><span>Traçabilité des positions</span></div>
    <MethodBox />
  </section></main>;
}
function MethodBox() {
  return <section className="method-box" id="methode"><span className="section-kicker">Méthode</span><h2>Calcul transparent</h2><div className="method-grid">
    <article><strong>1 · Curseur 0–100</strong><p>0 correspond au pôle A, 100 au pôle B, 50 à une position médiane.</p></article>
    <article><strong>2 · Proximité</strong><p>Pour chaque axe : proximité = 100 − |votre position − position du parti|.</p></article>
    <article><strong>3 · Score final</strong><p>Le score est la moyenne des proximités sur les axes documentés.</p></article>
    <article><strong>4 · Confiance</strong><p>IC0 à IC4 mesure la robustesse documentaire. Les positions IC0 sont exclues.</p></article>
  </div></section>;
}
function SliderCard({ axis, value, onChange, futureMode }) {
  const side = tone(value); const s = strength(value); const collective = simulatedCollective(axis.id, value); const execution = simulatedExecution(axis.id, collective);
  const leftOpacity = side === 'left' ? 0.45 + s * 0.55 : side === 'center' ? 0.85 : 0.38;
  const rightOpacity = side === 'right' ? 0.45 + s * 0.55 : side === 'center' ? 0.85 : 0.38;
  const style = { '--value': value, '--strength': s };
  return <article className={`axis-card tone-${side}`} style={style}>
    <div className="axis-head"><span className="axis-emoji">{axis.icon}</span><div><small>Question {axis.number || ''} · {axis.name}</small><h2>{axis.question}</h2><p className="measure">{axis.measure}</p></div></div>
    <div className="scale"><span style={{ opacity: leftOpacity }}>{axis.left}</span><b>{value}/100</b><span style={{ opacity: rightOpacity }}>{axis.right}</span></div>
    <input className="premium-slider" type="range" min="0" max="100" value={value} onChange={event => onChange(axis.id, Number(event.target.value))} aria-label={axis.question} />
    <div className={`dynamic-box ${side}`}><strong>{side === 'center' ? 'Position équilibrée' : side === 'left' ? 'Orientation pôle A' : 'Orientation pôle B'}</strong><p>{dynamicText(axis, value)}</p></div>
    <div className="keywords"><div>{axis.leftKeywords.map(k => <span className={side === 'left' ? 'active left' : ''} key={k}>{k}</span>)}</div><div>{axis.rightKeywords.map(k => <span className={side === 'right' ? 'active right' : ''} key={k}>{k}</span>)}</div></div>
    {futureMode && <div className="three-bars"><div className="bar-line"><span>1 · Votre vote</span><b>{value}/100</b><ProgressBar value={value} color="#ffffff" kind="personal" /></div><div className="bar-line"><span>2 · Résultat à 20h</span><b>{collective}/100</b><ProgressBar value={collective} color="#38bdf8" /></div><div className="bar-line"><span>3 · Application réelle</span><b>{execution}%</b><ProgressBar value={execution} color="#22c55e" /></div></div>}
  </article>;
}
function Questionnaire({ answers, setAnswer, showResults, reset }) {
  const [index, setIndex] = useState(0); const [futureMode, setFutureMode] = useState(false); const axis = axes[index];
  function next(){ if(index < axes.length - 1) setIndex(index + 1); else showResults(); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  function prev(){ if(index > 0) setIndex(index - 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  return <main className="page"><TopNav onReset={reset} currentScreen="questions" />
    <section className="panel heading-panel"><div><span className="section-kicker">Axe {index + 1} / {axes.length}</span><h1>{axis.name}</h1><p>Les partis sont masqués pendant le vote. Déplacez le curseur : le texte et la couleur changent pour vous aider à comprendre votre position.</p><label className="future-toggle"><input type="checkbox" checked={futureMode} onChange={e => setFutureMode(e.target.checked)} /> <span>Afficher le suivi du futur proche</span></label></div><div className="progress-wrap"><strong>{Math.round(((index + 1) / axes.length) * 100)}%</strong><ProgressBar value={((index + 1) / axes.length) * 100} /></div></section>
    {futureMode && <p className="maquette-note"><strong>Démonstration conceptuelle :</strong> les barres “résultat à 20h” et “application réelle” sont illustratives. Elles montrent le futur suivi des engagements.</p>}
    <section className="single-axis"><SliderCard axis={axis} value={answers[axis.id]} onChange={setAnswer} futureMode={futureMode} /></section>
    <div className="actions"><button className="btn muted" disabled={index===0} onClick={prev}>← Axe précédent</button><button className="btn primary" onClick={next}>{index === axes.length - 1 ? 'Voir mon résultat de vote →' : 'Axe suivant →'}</button></div>
  </main>;
}
function ResultPage({ answers, reset }) {
  const matching = useMemo(() => computeMatching(answers), [answers]); const top = matching.slice(0,4); const winner = top[0];
  const conv = topConvergences(winner); const div = topDivergences(winner);
  return <main className="page"><TopNav onReset={reset} currentScreen="results" />
    <section className="panel result-hero"><div><span className="section-kicker">Résultat du vote</span><h1>Votre bulletin</h1><p>Compatibilité ne signifie pas adhésion totale. Le résultat indique les proximités calculées sur les axes renseignés et documentés.</p></div><div className="winner" style={{ '--party': winner.color }}><span>Plus proche de vos positions</span><strong>{winner.name}</strong><b>{winner.match}%</b></div></section>
    <section className="panel party-list"><h2>Top 4 des proximités politiques</h2>{top.map((party, index) => <div className="party-row" key={party.id} style={{ '--party': party.color }}><span className="rank">{index + 1}</span><strong>{party.name}<small> · axes utilisés {party.axesUsed}/{axes.length} · IC moyen {party.avgIC.toFixed(1)}/4</small></strong><ProgressBar value={party.match} color={party.color} /><b>{party.match}%</b></div>)}</section>
    <section className="diagnostic-grid"><article className="diagnostic-card ok"><strong>{axes.length}/12</strong><span>Axes utilisés</span></article><article className="diagnostic-card partial"><strong>{avgResultIC(top)}/4</strong><span>IC moyen du Top 4</span></article><article className="diagnostic-card ok"><strong>V7.3</strong><span>Matrice source</span></article></section>
    <section className="tracking-panel"><article className="track-card"><h2>Convergences principales avec {winner.short}</h2>{conv.map(x => <p key={x.axis.id}><strong>{x.axis.name}</strong> — écart {x.distance} points · {IC_LABEL[x.ic]}</p>)}</article><article className="track-card is-partial"><h2>Divergences principales avec {winner.short}</h2>{div.map(x => <p key={x.axis.id}><strong>{x.axis.name}</strong> — écart {x.distance} points · {IC_LABEL[x.ic]}</p>)}</article></section>
    <section className="panel"><span className="section-kicker">Traçabilité</span><h2>Sources et méthode</h2><p>Les positions de partis proviennent de la matrice V7.3 bis. Les sources complètes sont conservées dans les documents Drive : matrice, consolidation, protocole sourcing et complément sourcing.</p><div className="actions left"><a className="btn muted" href="../">Retour au site Doctrine</a><button className="btn primary" onClick={reset}>Refaire le bulletin</button></div></section>
  </main>;
}
export default function App() {
  const [screen, setScreen] = useState('intro'); const [answers, setAnswers] = useState(START_ANSWERS);
  function setAnswer(axisId, value) { setAnswers(prev => ({ ...prev, [axisId]: value })); }
  function reset(){ setAnswers(START_ANSWERS); setScreen('intro'); window.scrollTo({ top: 0 }); }
  if(screen === 'intro') return <Intro start={() => setScreen('questions')} />;
  if(screen === 'questions') return <Questionnaire answers={answers} setAnswer={setAnswer} showResults={() => setScreen('results')} reset={reset} />;
  return <ResultPage answers={answers} reset={reset} />;
}
